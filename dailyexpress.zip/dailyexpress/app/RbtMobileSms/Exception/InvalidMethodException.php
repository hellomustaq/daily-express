<?php


namespace App\RbtMobileSms\Exception;


class InvalidMethodException extends Exception {

}
