<?php

namespace App\RbtMobileSms\Exception;


class Exception extends \Exception {

}
