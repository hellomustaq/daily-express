<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use URL;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        if(Str::contains(config('app.url'), 'https://') && config('app.env') == 'production') {
            URL::forceScheme('https');
        }

        // Front Theme View
        $this->loadViewsFrom(base_path('theme/views'), 'theme');
    }
}
