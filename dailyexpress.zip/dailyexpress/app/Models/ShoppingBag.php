<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class ShoppingBag extends Model
{
    protected $primaryKey = 'sb_id';
}
