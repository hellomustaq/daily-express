<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientAccountBalance extends Model
{
    protected $primaryKey = 'cab_id';
}
