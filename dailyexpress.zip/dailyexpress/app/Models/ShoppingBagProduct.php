<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class ShoppingBagProduct extends Model
{
    protected $primaryKey = 'sbp_id';
}
