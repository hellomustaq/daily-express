<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class ProductSupplyDetail extends Model
{
    /**
     * The table primary key.
     */
    protected $primaryKey  = 'psd_id';
}
