<?php $__env->startSection('sub-title', 'Franchise'); ?>
<?php $__env->startSection('page-description', 'All Franchise'); ?>

<?php $__env->startSection('franchise-active', 'active'); ?>
<?php $__env->startSection('franchise-all-active', 'active'); ?>

<?php $__env->startSection('header-action'); ?>
    <ul class="nav justify-content-end">
        <li class="nav-item text-center">
            <a class="nav-link btn btn-light" href="<?php echo e(route('admin.franchise-control.add')); ?>">
                <i class="fa fa-plus"></i>
                <span class="d-none d-sm-block">Create Merchant</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">

        <?php if(Session::has('status')): ?>
            <div class="alert alert-info text-center" role="alert">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>





        <franchise-data-table
                api_url="<?php echo e(route('admin.api.franchise-control.all')); ?>">
        </franchise-data-table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/Franchise/resources/views/admin/franchise-controls/index.blade.php ENDPATH**/ ?>