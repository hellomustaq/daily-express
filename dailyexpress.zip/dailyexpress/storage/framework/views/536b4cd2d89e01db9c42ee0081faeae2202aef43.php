<?php $__env->startSection('sub-title', 'Create New Product Brand'); ?>
<?php $__env->startSection('page-description', 'Create New Product Brand'); ?>

<?php $__env->startSection('brand-active', 'active'); ?>
<?php $__env->startSection('brand-new-active', 'active'); ?>


<?php $__env->startSection('admin-content'); ?>
    <div class="rbt-product-brands">
        <div class="card">
            <div class="card-header">
                <strong><i class="fa fa-plus"></i> Add</strong> Brand
            </div>
            <div class="card-body">
                <div class="create-brand-container">
                    <create-product-brand show_as="page"></create-product-brand>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/product-brands/create.blade.php ENDPATH**/ ?>