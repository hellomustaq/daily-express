<?php $__env->startSection('title', 'Email Verification :: '); ?>
<?php $__env->startSection('description', getSiteBasic('site_description')); ?>
<?php $__env->startSection('keywords', getSiteBasic('site_keywords')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__env->startComponent('theme::components.breadcrumb', [
            'data'  => [
                //['url' => '#', 'title' => 'Shop']
            ],
            'active'   => 'Email/Mobile Verification'
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-3 my-md-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card bsoft-card">
                <div class="card-header text-center">Verify Your Email/Mobile</div>

                <?php if(session('resent') || (auth()->user()->email && !auth()->user()->hasVerifiedEmail())): ?>
                    <div class="card-body text-center">
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                            <br>
                            It may take upto <strong>0-5 Minutes.</strong>
                        </div>

                        <span style="font-size: 13px; letter-spacing: 0.03em;">
                            <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                            <br>
                            Didn't receive the email yet?
                            <a href="<?php echo e(route('verification.resend')); ?>" style="text-decoration: underline; color: var(--accent-color);" v-tooltip.top-bottom="'Request Another Verification Email'">
                                <strong>click to resend</strong>
                            </a>
                        </span>
                    </div>
                <?php endif; ?>

                <?php if(session('mobile') || (auth()->user()->mobile && !auth()->user()->hasVerifiedEmail())): ?>
                    <div class="card-body text-center">
                        <?php if(session('mobile')): ?>
                            <div class="alert alert-success" role="alert">
                                A fresh verification code has been sent to your mobile number.
                                <br>
                                It may take upto <strong>0-5 Minutes.</strong>
                            </div>
                        <?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <form method="POST" class="text-center" action="<?php echo e(route('verification.mobile.verify', ['id' => auth()->id()])); ?>">
                            <?php echo csrf_field(); ?>
                            <label class="sr-only" for="mobile_verify">Verification Code</label>
                            <input type="text" class="form-control mb-2 mx-auto text-center" name="code" id="mobile_verify" placeholder="Your Verification Code" style="width: 250px;">

                            <button type="submit" class="btn btn-success mb-2">Verify</button>
                        </form>

                        <span style="font-size: 13px; letter-spacing: 0.03em;">
                            Before proceeding, please check your Mobile for a verification code.
                            <br>
                            Didn't receive the code yet?
                            <a href="<?php echo e(route('verification.mobile.resend')); ?>" style="text-decoration: underline; color: var(--accent-color);" v-tooltip.top-bottom="'Request Another Verification Code'">
                                <strong>click to resend</strong>
                            </a>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/theme/views/auth/verify.blade.php ENDPATH**/ ?>