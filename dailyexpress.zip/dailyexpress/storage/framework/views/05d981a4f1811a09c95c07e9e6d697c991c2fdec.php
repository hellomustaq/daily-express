<?php $__env->startSection('sub-title', 'Coupons'); ?>
<?php $__env->startSection('page-description', 'All coupons'); ?>

<?php $__env->startSection('marketing-active', 'active'); ?>
<?php $__env->startSection('marketing-coupons-active', 'active'); ?>

<?php $__env->startSection('header-action'); ?>

    <ul class="nav justify-content-end">
        <li class="nav-item text-center">
            <a href="<?php echo e(route('admin.coupon.create')); ?>" class="nav-link btn btn-light">
                <i class="fa fa-plus"></i>
                <span class="d-sm-block">Create</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">
        <div class="card new-admin">
            <div class="card-header">
                <strong><i class="fa fa-info-circle"></i> All</strong> Coupons
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Coupon</th>
                                <th>Discount</th>
                                <th>Max Discount</th>
                                <th>Start From</th>
                                <th>Expires At</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($coupon->coupon_code); ?></td>
                                    <td><?php echo e(($coupon->coupon_discount_amount && $coupon->coupon_discount_amount > 0) ? $coupon->coupon_discount_amount . ' TK' : $coupon->coupon_discount_percentage . '%'); ?></td>
                                    <td><?php echo e(number_format($coupon->coupon_max_amount, 2) . ' TK'); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($coupon->coupon_started)->format('j F Y')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($coupon->coupon_expired)->format('j F Y')); ?></td>
                                    <td><?php echo e(($coupon->coupon_active) ? 'Active' : 'Inactive'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/marketing/coupons/index.blade.php ENDPATH**/ ?>