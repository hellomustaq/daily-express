<div class="categories-menu-container">
    <div class="content-title" id="sidebarContentTitle">
        <h3 class="text-uppercase">
            Categories <span class="float-right"> <i class="icon ion-md-list"></i> </span>
        </h3>
    </div>

    <div class="category-menu" id="sidebarMainMenu" <?php if(Route::currentRouteName() !== 'index'): ?> style="display: none;" <?php endif; ?>>
        <ul>
            <?php $__currentLoopData = getCategories('parent'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(getCategories('child', $category->category_id) == null || count(getCategories('child', $category->category_id)) <= 0): ?>
                    <li class="menu-item-parent">
                        <a href="<?php echo e(route('category.single', ['slug' => $category->category_slug])); ?>">
                            <span><i class="icon ion-logo-buffer"></i></span>
                            <?php echo e($category->category_title); ?>

                        </a>
                    </li>
                <?php else: ?>
                    <li class="menu-item-parent has-children">
                        <a href="<?php echo e(route('category.single', ['slug' => $category->category_slug])); ?>">
                            <i class="icon ion-logo-buffer mr-1"></i> <?php echo e($category->category_title); ?>

                            <span class="float-right d-none d-lg-block"><i class="icon ion-ios-arrow-forward"></i></span>
                            <span class="menu-toggler float-right d-lg-none" style="font-size: 20px;" title="Click To Toggle">
                                <i class="icon ion-ios-add"></i>
                            </span>
                        </a>

                        <ul class="categories-sub-menu">
                            <?php $__currentLoopData = getCategories('child', $category->category_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(getCategories('filtering', $child->category_id) === null || count(getCategories('filtering', $child->category_id)) <= 0): ?>
                                    <li class="menu-item-child">
                                        <a href="<?php echo e(route('category.single', ['slug' => $child->category_slug])); ?>">
                                            <?php echo e($child->category_title); ?>

                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="menu-item-child has-child">
                                        <a href="<?php echo e(route('category.single', ['slug' => $child->category_slug])); ?>">
                                            <?php echo e($child->category_title); ?>

                                        </a>
                                        <ul class="categories-child-sub-menu">
                                            <?php $__currentLoopData = getCategories('filtering', $child->category_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="menu-item-filter">
                                                    <a href="<?php echo e(route('category.single', ['slug' => $filter->category_slug])); ?>">
                                                        <?php echo e($filter->category_title); ?>

                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li class="category-image">
                                <?php if($catBanner = getBanners('category_menu_banner_' . $category->category_id, true)): ?>
                                    <a class="d-block p-0" href="<?php echo e($catBanner->banner_target_url); ?>" <?php if($catBanner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
                                        <img src="<?php echo e(imageCache($catBanner->banner_img)); ?>" class="w-100 h-100" alt="">
                                    </a>
                                <?php else: ?>
                                    <a class="d-block p-0" href="#">
                                        <img src="https://via.placeholder.com/850x140?text=(850x140+px)" class="w-100 h-100" alt="">
                                    </a>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if($index == 9) break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/theme/views/partials/main-menu.blade.php ENDPATH**/ ?>