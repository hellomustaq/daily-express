<?php $__env->startSection('sub-title', 'Site Options'); ?>
<?php $__env->startSection('page-description', 'Set Site Options'); ?>

<?php $__env->startSection('site-information-active', 'active'); ?>
<?php $__env->startSection('site-details-active', 'active'); ?>



<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">
        <div class="card new-admin">
            <div class="card-header">
                <strong><i class="fa fa-info-circle"></i> Shop</strong> Information
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('shop_info.save')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="first_name" class="col-sm-2 col-form-label">Shop Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php echo e($errors->has('site_title') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('site_title')); ?>"
                                   id="site_title" name="site_title" placeholder="Shop Name" required autofocus>
                            <?php if($errors->has('site_title')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('site_title')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="site_email" class="col-sm-2 col-form-label">Shop Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control <?php echo e($errors->has('site_email') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('site_email')); ?>"
                                   id="site_email" name="site_email" placeholder="Shop Email Address">
                            <?php if($errors->has('site_email')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('site_email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="site_mobile" class="col-sm-2 col-form-label">Shop Mobile</label>
                        <div class="col-sm-10">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">+880</span>
                                </div>
                                <input type="tel" class="form-control <?php echo e($errors->has('site_mobile') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('site_mobile')); ?>"
                                       id="site_mobile" name="site_mobile" placeholder="Shop Mobile Number" required>
                                <?php if($errors->has('site_mobile')): ?>
                                    <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('site_mobile')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="site_description" class="col-sm-2 col-form-label">Shop Description</label>
                        <div class="col-sm-10">
                            <textarea id="site_description" rows="5" name="site_description" class="form-control <?php echo e($errors->has('site_description') ? 'is-invalid' : ''); ?>" ><?php echo getSiteBasic('site_description'); ?></textarea>
                            <?php if($errors->has('site_description')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('site_description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="site_address" class="col-sm-2 col-form-label">Shop Address</label>
                        <div class="col-sm-10">
                            <textarea id="site_address" rows="3" name="site_address" class="form-control <?php echo e($errors->has('site_address') ? 'is-invalid' : ''); ?>" ><?php echo getSiteBasic('site_address'); ?></textarea>
                            <?php if($errors->has('site_address')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('site_address')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="map_address" class="col-sm-2 col-form-label">Google Map Address</label>
                        <div class="col-sm-10">
                            <input type="url" class="form-control <?php echo e($errors->has('map_address') ? 'is-invalid' : ''); ?>" value="<?php echo e(urldecode(getSiteBasic('map_address'))); ?>"
                                   id="map_address" name="map_address" placeholder="Google Map Address Link">
                            <?php if($errors->has('map_address')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('map_address')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="site_keywords" class="col-sm-2 col-form-label">Shop Keywords</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php echo e($errors->has('site_keywords') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('site_keywords')); ?>"
                                   id="site_keywords" name="site_keywords" placeholder="Shop Keywords">
                            <?php if($errors->has('site_keywords')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('site_keywords')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="site_logo" class="col-sm-2 col-form-label">Shop Logo</label>
                        <div class="col-sm-10">
                            <div id="rmmUpload">
                                <?php if(getSiteBasic('site_logo')): ?>
                                    <img src="<?php echo e(url('uploads/public/cache/original/' . getSiteBasic('site_logo'))); ?>" alt="<?php echo e(getSiteBasic('site_title')); ?>" style="max-height: 250px; max-width: 300px;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/icon_bw.png')); ?>" alt="" style="max-height: 250px; max-width: 300px;">
                                <?php endif; ?>
                                <input type="hidden" id="site_logo" name="site_logo" value="">
                            </div>
                            <button type="button" class="btn btn-warning mt-3" data-toggle="modal" data-target="#rbtMediaManager">
                                Change Logo
                            </button>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-10 offset-sm-2">
                            <input type="submit" class="btn btn-success" value="Save">
                        </div>
                    </div>
                    <rbt-media-manager directory="main" :user_id="$root.admin.id" url_prefix="/bs-mm-api" show_as="modal" element_id="rmmUpload"></rbt-media-manager>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/site-information/index.blade.php ENDPATH**/ ?>