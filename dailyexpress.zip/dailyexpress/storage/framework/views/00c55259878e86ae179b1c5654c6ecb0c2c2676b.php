<?php $__env->startSection('sub-title', 'Add New Franchise'); ?>
<?php $__env->startSection('page-description', 'Add New Franchise'); ?>

<?php $__env->startSection('franchise-active', 'active'); ?>
<?php $__env->startSection('franchise-new-active', 'active'); ?>



<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">
        <div class="card new-admin">
            <div class="card-header">
                <strong><i class="fa fa-plus"></i> Add</strong> New Franchise
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.franchise-control.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="first_name" class="col-sm-2 col-form-label">Name</label>
                        <label for="last_name" class="sr-only">Last Name</label>
                        <div class="col-sm-5">
                            <input type="text" class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('first_name')); ?>"
                                   id="first_name" name="first_name" placeholder="First Name" required autofocus>
                            <?php if($errors->has('first_name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col-sm-5">
                            <input type="text" class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('last_name')); ?>"
                                   id="last_name" name="last_name" placeholder="Last Name" required>
                            <?php if($errors->has('last_name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('last_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="email" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>"
                                   id="email" name="email" placeholder="Email Address" required>
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="password" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" id="password"
                                   name="password" placeholder="Password" aria-describedby="passwordHelp" required>
                            <small id="passwordHelp" class="form-text text-muted">
                                Password must be at least 6 characters.
                            </small>
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="confPassword" class="col-sm-2 col-form-label">Confirm Password</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="confPassword" name="password_confirmation" placeholder="Confirm Password" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="mobile" class="col-sm-2 col-form-label">Mobile No</label>
                        <div class="col-sm-10">
                            <input type="tel" class="form-control <?php echo e($errors->has('mobile_primary') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('mobile_primary')); ?>"
                                   id="mobile" name="mobile_primary" placeholder="Primary Mobile Number" required>
                            <?php if($errors->has('mobile_primary')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('mobile_primary')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10 offset-sm-2">
                            <input type="submit" class="btn btn-success" value="Create Franchise">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/franchise-controls/create.blade.php ENDPATH**/ ?>