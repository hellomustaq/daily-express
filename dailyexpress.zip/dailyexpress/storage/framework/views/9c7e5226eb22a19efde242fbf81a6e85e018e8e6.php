

<?php $__env->startSection('sub-title', 'Create Category'); ?>
<?php $__env->startSection('page-description', 'Create new Categories'); ?>

<?php $__env->startSection('categories-active', 'active'); ?>
<?php $__env->startSection('categories-new-active', (isset($categoryId) ? '' : 'active' )); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-categories">
        <div class="admin-content-header-summary">
            <div class="row">
                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header rbt-bg-main">Main <strong>Categories</strong></h5>
                        <div class="card-body rbt-text-main">
                            <span><?php echo e(getOrderSummary()->pending); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header">Sub <strong>Categories</strong></h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->today; ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header">Filtering <strong>Categories</strong></h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->this_month; ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header">Inactive <strong>Categories</strong></h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->last_month; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if(isset($categoryId)): ?>
            <new-category category_id="<?php echo e($categoryId); ?>"></new-category>
        <?php else: ?>
            <new-category></new-category>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/categories/create.blade.php ENDPATH**/ ?>