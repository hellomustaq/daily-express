<?php if(isset($product)): ?>
    <?php $__env->startSection('sub-title', 'Edit Product'); ?>
    <?php $__env->startSection('page-description', 'Edit ' . $product->product_title); ?>
<?php else: ?>
    <?php $__env->startSection('sub-title', 'Add Product'); ?>
    <?php $__env->startSection('page-description', 'Add New Product'); ?>
<?php endif; ?>


<?php $__env->startSection('custom-header-style-scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('products-active', 'active'); ?>
<?php $__env->startSection('products-new-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-products">
        
        <div class="admin-content-header-summary">
            <div class="row">
                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header rbt-bg-main"><strong>Featured</strong> Products</h5>
                        <div class="card-body rbt-text-main">
                            <span><?php echo e($summary->featured); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Out of</strong> Stock</h5>
                        <div class="card-body">
                            <span><?php echo e($summary->out_of_stock); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Inactive</strong> Products</h5>
                        <div class="card-body">
                            <span><?php echo e($summary->inactive); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Total</strong> Products</h5>
                        <div class="card-body">
                            <span><?php echo e($summary->total); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <?php if(isset($product)): ?>
            <create-product product_id="<?php echo e($product->product_id); ?>"></create-product>
        <?php else: ?>
            <create-product></create-product>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/products/create.blade.php ENDPATH**/ ?>