<?php $__env->startSection('sub-title', 'Site Config'); ?>
<?php $__env->startSection('page-description', 'Set Site Configuration'); ?>

<?php $__env->startSection('site-information-active', 'active'); ?>
<?php $__env->startSection('site-config-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">
        <div class="card new-admin">
            <div class="card-header">
                <strong><i class="fa fa-info-circle"></i> Shop</strong> Config
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('shop_info.config.save')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="first_name" class="col-sm-2 col-form-label">Shop Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control <?php echo e($errors->has('site_title') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('site_title')); ?>"
                                   id="site_title" name="site_title" placeholder="Shop Name" required autofocus>
                            <?php if($errors->has('site_title')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('site_title')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="default_product_image" class="col-sm-2 col-form-label">Default Product Image</label>
                        <div class="col-sm-10">
                            <div id="rmmUpload">
                                <?php if($product = getSiteBasic('default_product_image')): ?>
                                    <img src="<?php echo e(url('uploads/public/cache/original/' . $product)); ?>" alt="" style="max-height: 250px; max-width: 300px;">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/icon_bw.png')); ?>" alt="" style="max-height: 250px; max-width: 300px;">
                                <?php endif; ?>
                                <input type="hidden" id="default_product_image" name="default_product_image" value="">
                            </div>
                            <button type="button" class="btn btn-warning mt-3" data-toggle="modal" data-target="#rbtMediaManager">
                                Change Logo
                            </button>
                        </div>
                    </div>



                    <div class="form-group row">
                        <div class="col-sm-10 offset-sm-2">
                            <input type="submit" class="btn btn-success" value="Save">
                        </div>
                    </div>
                    <rbt-media-manager directory="main" :user_id="$root.admin.id" url_prefix="/bs-mm-api" show_as="modal" element_id="rmmUpload"></rbt-media-manager>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/site-information/config.blade.php ENDPATH**/ ?>