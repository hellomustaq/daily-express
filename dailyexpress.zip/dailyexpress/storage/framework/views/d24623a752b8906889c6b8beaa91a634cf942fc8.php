<?php $__env->startSection('allApprovedProducts-title'); ?>
    All Approved Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection('allApprovedProducts'); ?>
    <div class="content-wrapper px-1">

        
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2" style="background-color: #00796b; color: #ffeeee">
                    <div class="card-header do-custom-header offset-4">
                        <h1 class="text-center text-uppercase" >Approved Products List</h1>
                    </div>
                </div>
            </div>
        </div>
        <?php if(session()->has('message')): ?>
            <div class="text-center alert alert-<?php echo e(session('type')); ?>">
                <h5><?php echo e(session('message')); ?></h5>
            </div>
        <?php endif; ?>

        <?php if(session()->has('productDeleteMessage')): ?>
            <div class="alert alert-danger">
                <h5><?php echo e(Session::get('productDeleteMessage')); ?></h5>
            </div>
        <?php endif; ?>

        

        <div class="row">
            <div class="col-md-12">
                <div class="card comp-card">
                    <div class="card-body">
                        <div class="table-responsive" >
                            <table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%" style="background-color: #e0e0e0">
                                <thead>
                                    <tr>
                                        <th scope="col">SL</th>
                                        <th scope="col">Product Code</th>
                                        <th scope="col">Product Title</th>
                                        <th scope="col">P.U.C.</th>
                                        <th scope="col">MRP</th>
                                        <th scope="col">Stock</th>
                                        <th scope="col">Availability</th>
                                        <th scope="col">Images</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $sellerProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sellerProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td width="40"><?php echo e($index+1); ?></td>
                                            <td width="100"><?php echo e($sellerProduct->product_code); ?></td>
                                            <td  width="130">

                                                <a href="<?php echo e(route('seller.previewProduct', ['preview_product_id' => $sellerProduct->product_id])); ?>">
                                                    <?php echo e($sellerProduct->product_name); ?>

                                                </a>
                                            </td>
                                            <td width="60"><?php echo e($sellerProduct->product_unit_cost); ?></td>
                                            <td width="60"><?php echo e($sellerProduct->product_unit_mrp); ?></td>
                                            <td width="60"><?php echo e($sellerProduct->product_unit_stock); ?></td>
                                            <td width="60"><?php echo e($sellerProduct->product_availability); ?></td>
                                            <?php
                                                $sellerProductImages = \App\SellerProductImages::where('product_id', $sellerProduct->product_id)->get();
                                            ?>
                                            <td width="100">
                                                <?php $__currentLoopData = $sellerProductImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <img src="<?php echo e(asset($image->images_path)); ?>" width=34 height="21">
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td width="130">
                                                <a href="<?php echo e(route('seller.previewProduct', ['preview_product_id' => $sellerProduct->product_id])); ?>" class="btn btn-success btn-sm"
                                                ><i class="fa fa-eye"></i></a>

                                                <a href="<?php echo e(route('seller.editProduct',['edit_prod`uct_id' => $sellerProduct->product_id])); ?>" class="btn btn-warning btn-sm"
                                                   onclick="return confirm('Really! Do you want to Update Product details?')"><i class="fa fa-pen"></i></a>

                                                <a href="<?php echo e(route('seller.deleteProduct',['product_id' => $sellerProduct->product_id ])); ?>" class="btn btn-danger btn-sm"
                                                   onclick=" return confirm('Are you sure to delete this item?')"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($sellerProducts->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('seller.layouts.seller_dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/seller/seller_dashboard/approved-products.blade.php ENDPATH**/ ?>