<?php $__env->startSection('title', 'Welcome :: '); ?>
<?php $__env->startSection('description', getSiteBasic('site_description')); ?>
<?php $__env->startSection('keywords', getSiteBasic('site_keywords')); ?>

<?php $__env->startSection('og-meta'); ?>
    <meta property="og:title" content="<?php echo e(getSiteBasic('site_title')); ?>">
    <meta property="og:description" content="<?php echo e(getSiteBasic('site_description')); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo e(Request::fullUrl()); ?>">
    <meta property="og:image" content="<?php echo e(imageCache(getSiteBasic('site_logo'))); ?>">

    <meta name="twitter:title" content="<?php echo e(getSiteBasic('site_title')); ?>">
    <meta name="twitter:description" content="<?php echo e(getSiteBasic('site_description')); ?>">
    <meta name="twitter:image" content="<?php echo e(imageCache(getSiteBasic('site_logo'))); ?>">
    <meta name="twitter:card" content="<?php echo e(imageCache(getSiteBasic('site_logo'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <section class="index-inner-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-xl-9 offset-lg-4 offset-xl-3">
                    <div class="slider-wrapper">

                        <ul id="sb-slider" class="sb-slider">
                            <?php $__empty_1 = true; $__currentLoopData = getBanners('index-main-slider'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li>
                                    <a href="#" target="_blank">
                                        <img src="<?php echo e(imageCache($banner->banner_img, 'original')); ?>" alt="">
                                    </a>
                                    <?php if($banner->banner_target_url && $banner->banner_target_url != '#'): ?>
                                        <div class="sb-description">
                                            <a class="btn btn-info" href="<?php echo e($banner->banner_target_url); ?>" <?php if($banner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
                                                <?php echo e($banner->banner_target_text); ?>

                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li>
                                    <a href="#" target="_blank">
                                        <img src="https://via.placeholder.com/1333x750?text=Promotional+Image(1335x750)" alt="">
                                    </a>
                                    <div class="sb-description">

                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>

                        <div id="nav-arrows" class="nav-arrows">
                            <a href="#" title="Next">Next</a>
                            <a href="#" title="Previous">Previous</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    

    
    <section class="index-small-banner">
        <div class="container">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = getBanners('index-main-banner'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6">
                        <div class="banner-content">
                            <a href="<?php echo e($banner->banner_target_url); ?>" <?php if($banner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
                                <img class="hvr-wobble-top" src="<?php echo e(imageCache($banner->banner_img)); ?>" alt="">
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-6">
                        <div class="banner-content">
                            <a href="#">
                                <img class="hvr-wobble-top" src="<?php echo e(staticAsset('theme/images/banners/index_top_banner_1.jpg')); ?>" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="banner-content">
                            <a href="#">
                                <img class="hvr-wobble-top" src="<?php echo e(staticAsset('theme/images/banners/index_top_banner_2.jpg')); ?>" alt="">
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    

    
    <section class="index-tabbed-products">
        <div class="container">
            <ul class="nav nav-tabs" id="indexProductsTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="new-product-tab" data-toggle="tab" href="#newProducts" role="tab" aria-controls="newProducts" aria-selected="true">New Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="featured-products-tab" data-toggle="tab" href="#featuredProducts" role="tab" aria-controls="featuredProducts" aria-selected="false">Featured Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="offered-products-tab" data-toggle="tab" href="#offeredProducts" role="tab" aria-controls="offeredProducts" aria-selected="false">Offered Products</a>
                </li>
            </ul>
            <div class="tab-content" id="indexProductsTabContent">
                <div class="tab-pane fade show active" id="newProducts" role="tabpanel" aria-labelledby="new-product-tab">
                    <div class="row">
                        <div class="index-tabbed-carousel product-carousel owl-carousel owl-loaded owl-loaded">
                            <?php $__currentLoopData = productsByType('new', 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3">
                                    <?php $__env->startComponent('theme::components.product-grid', ['product' => $product]); ?>
                                        <?php $__env->slot('image'); ?>
                                            <?php if($product->product_img_main && strlen($product->product_img_main) > 5): ?>
                                                <img src="<?php echo e(imageCache($product->product_img_main, '400')); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php elseif(getSiteBasic('default_product_image')): ?>
                                                <img src="<?php echo e(imageCache(getSiteBasic('default_product_image'))); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php else: ?>
                                                <img src="<?php echo e(staticAsset('theme/images/logos/default_product.png')); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php endif; ?>
                                        <?php $__env->endSlot(); ?>
                                    <?php echo $__env->renderComponent(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="featuredProducts" role="tabpanel" aria-labelledby="featured-products-tab">
                    <div class="row">
                        <div class="index-tabbed-carousel product-carousel owl-carousel owl-loaded owl-loaded">
                            <?php $__currentLoopData = productsByType('featured', 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3">
                                    <?php $__env->startComponent('theme::components.product-grid', ['product' => $product]); ?>
                                        <?php $__env->slot('image'); ?>
                                            <?php if($product->product_img_main && strlen($product->product_img_main) > 5): ?>
                                                <img src="<?php echo e(imageCache($product->product_img_main, '400')); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php elseif(getSiteBasic('default_product_image')): ?>
                                                <img src="<?php echo e(imageCache(getSiteBasic('default_product_image'))); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php else: ?>
                                                <img src="<?php echo e(staticAsset('theme/images/logos/default_product.png')); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php endif; ?>
                                        <?php $__env->endSlot(); ?>
                                    <?php echo $__env->renderComponent(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="offeredProducts" role="tabpanel" aria-labelledby="offered-products-tab">
                    <div class="row">
                        <div class="index-tabbed-carousel product-carousel owl-carousel owl-loaded owl-loaded">
                            <?php $__currentLoopData = productsByType('offered', 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3">
                                    <?php $__env->startComponent('theme::components.product-grid', ['product' => $product]); ?>
                                        <?php $__env->slot('image'); ?>
                                            <?php if($product->product_img_main && strlen($product->product_img_main) > 5): ?>
                                                <img src="<?php echo e(imageCache($product->product_img_main, '400')); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php elseif(getSiteBasic('default_product_image')): ?>
                                                <img src="<?php echo e(imageCache(getSiteBasic('default_product_image'))); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php else: ?>
                                                <img src="<?php echo e(staticAsset('theme/images/logos/default_product.png')); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php endif; ?>
                                        <?php $__env->endSlot(); ?>
                                    <?php echo $__env->renderComponent(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    <?php $__empty_1 = true; $__currentLoopData = getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <section class="categorised-products mb-5">
            <div class="container">
                <div class="card bsoft-card">
                    <div class="card-header">
                        <a href="<?php echo e(route('category.single', ['slug' => $category->category_slug])); ?>">
                            <?php echo e($category->category_title); ?>

                        </a>

                        <a class="float-right" style="font-size: 14px; color: var(--accent-color); text-transform: uppercase;"
                           href="<?php echo e(route('category.single', ['slug' => $category->category_slug])); ?>"
                           v-tooltip.top-center="'View More Products for this Category'">
                            View More
                        </a>
                    </div>

                    <div class="card-body border-0 p-0">
                        <div class="row">
							<div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-3">
                                <?php if($catBanner = getBanners('category_sidebar_banner_' . $category->category_id, true)): ?>
                                    <a class="product-grid d-block p-0" href="<?php echo e($catBanner->banner_target_url); ?>" <?php if($catBanner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
                                        <img src="<?php echo e(imageCache($catBanner->banner_img)); ?>" class="w-100 h-100" alt="">
                                    </a>
                                <?php else: ?>
                                    <a class="product-grid d-block p-0" href="#">
                                        <img src="https://via.placeholder.com/300x490?text=(300x490+px)" class="w-100 h-100" alt="">
                                    </a>
                                <?php endif; ?>
							</div>
                            <?php $__empty_2 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-3">
                                    <?php $__env->startComponent('theme::components.product-grid', ['product' => $product]); ?>
                                        <?php $__env->slot('image'); ?>
                                            <?php if($product->product_img_main && strlen($product->product_img_main) > 5): ?>
                                                <img src="<?php echo e(imageCache($product->product_img_main, '400')); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php elseif(getSiteBasic('default_product_image')): ?>
                                                <img src="<?php echo e(imageCache(getSiteBasic('default_product_image'))); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php else: ?>
                                                <img src="<?php echo e(staticAsset('theme/images/logos/default_product.png')); ?>" alt="<?php echo e($product->product_title); ?>" class="hvr-buzz-out">
                                            <?php endif; ?>
                                        <?php $__env->endSlot(); ?>
                                    <?php echo $__env->renderComponent(); ?>
                                </div>
                                <?php if($p >= 2) break; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        
        <?php
            $banners = getBanners('index-main-banner', false, 4);
            if($banners && (intval($index) % 2 == 0)) {
                $banners = collect($banners)->splice(-2, 2);
            } else {
                $banners = collect($banners)->splice(0, 2);
            }
        ?>
        <section class="index-small-banner">
            <div class="container">
                <div class="row">
                    <?php $__empty_2 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <div class="col-md-6">
                            <div class="banner-content">
                                <a href="<?php echo e($banner->banner_target_url); ?>" <?php if($banner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
                                    <img class="hvr-wobble-top" src="<?php echo e(imageCache($banner->banner_img)); ?>" alt="">
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <div class="col-md-6">
                            <div class="banner-content">
                                <a href="#">
                                    <img class="hvr-wobble-top" src="<?php echo e(staticAsset('theme/images/banners/index_top_banner_1.jpg')); ?>" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="banner-content">
                                <a href="#">
                                    <img class="hvr-wobble-top" src="<?php echo e(staticAsset('theme/images/banners/index_top_banner_2.jpg')); ?>" alt="">
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/Franchise/theme/views/welcome.blade.php ENDPATH**/ ?>