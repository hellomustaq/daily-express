<?php $__env->startSection('title', $title . ' :: '); ?>
<?php $__env->startSection('description', Str::limit(strip_tags($description), 180)); ?>
<?php $__env->startSection('keywords', $keywords); ?>

<?php if(isset($product) && $product): ?>
    <?php $__env->startSection('og-meta'); ?>
        <meta property="og:title" content="<?php echo e($product->product_title); ?>">
        <meta property="og:description" content="<?php echo e(Str::limit(strip_tags($description), 180)); ?>">
        <meta property="og:type" content="product">
        <meta property="og:url" content="<?php echo e(Request::fullUrl()); ?>">
        <meta property="og:site_name" content="<?php echo e(getSiteBasic('site_title')); ?>">
        <meta property="og:image" content="<?php echo e(imageCache($product->product_img_main)); ?>">
        <meta property="product:condition" content="new">
        <meta property="product:availability" content="<?php echo e($product->product_availability_status); ?>">
        <meta property="product:price:amount" content="<?php echo e($product->product_unit_mrp); ?>">
        <meta property="product:price:currency" content="BDT">

        <meta name="twitter:title" content="<?php echo e($product->product_title); ?>">
        <meta name="twitter:description" content="<?php echo e(Str::limit(strip_tags($description), 180)); ?>">
        <meta name="twitter:image" content="<?php echo e(imageCache($product->product_img_main)); ?>">
        <meta name="twitter:card" content="<?php echo e(imageCache($product->product_img_main)); ?>">
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__env->startComponent('theme::components.breadcrumb', [
            'data'  => [
                ['url' => '#', 'title' => 'Shop']
            ],
            'active'   => $title
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="single-product-section">
        <div class="container">
            <div class="row">

                <div class="col-md-8 col-lg-9">
                    <?php if(isset($error)): ?>
                        <div class="alert alert-danger py-5" role="alert">
                            <?php echo e($error); ?>

                        </div>
                    <?php else: ?>
                        <?php $__env->startComponent('theme::components.product-single', ['product' => $product]); ?>

                        <?php echo $__env->renderComponent(); ?>
                    <?php endif; ?>
                </div>

                <div class="col-md-4 col-lg-3">
                    <aside class="shop-sidebar">
                        <div class="shop-sidebar-image-top d-none d-lg-block">
                            <?php if($catBanner = getBanners('sidebar_banner', true)): ?>
                                <a class="d-block p-0" href="<?php echo e($catBanner->banner_target_url); ?>" <?php if($catBanner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
                                    <img src="<?php echo e(imageCache($catBanner->banner_img)); ?>" class="w-100 h-100" alt="">
                                </a>
                            <?php else: ?>
                                <a class="d-block p-0" href="#">
                                    <img src="https://via.placeholder.com/300x490?text=(300x490+px)" class="w-100 h-100" alt="">
                                </a>
                            <?php endif; ?>
                        </div>

                        
                    </aside>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/theme/views/product-details.blade.php ENDPATH**/ ?>