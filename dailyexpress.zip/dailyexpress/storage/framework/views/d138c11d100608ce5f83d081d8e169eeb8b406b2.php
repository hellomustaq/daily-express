<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('sellerTitle'); ?></title>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('seller/css/seller_main.css')); ?>">
    <link href="<?php echo e(asset('seller_dashboard/plugins/summernote/summernote-bs4.css/summernote-bs4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('seller_dashboard/dist/css/datatables.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('seller_dashboard/dist/css/bootstrap.min.css')); ?>">

</head>
<body class="do-seller-regi-homepage">
    
    <?php echo $__env->yieldContent('sellerRegistration'); ?>

    
    <?php echo $__env->yieldContent('seller_approval'); ?>




    
    <script src="<?php echo e(asset('js/jquery-3.3.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('seller/js/seller_main.js')); ?>"></script>
    <script src="<?php echo e(asset('seller_dashboard/plugins/summernote/summernote-bs4.js/summernote-bs4.min.js')); ?>"></script>


</body>
</html>
<?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/seller/seller-master.blade.php ENDPATH**/ ?>