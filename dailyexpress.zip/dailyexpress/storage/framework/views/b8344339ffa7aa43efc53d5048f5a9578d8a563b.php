<?php $__env->startSection('sellerDashboardTitle'); ?>
    Seller Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sellerDashboard'); ?>

    
    <div class="content-wrapper" style="background-color: #E0E0E0">
        <?php if(session()->has('errorMessage')): ?>
            <div class="alert alert-danger">
                <?php echo e(session()->get('errorMessage')); ?>

            </div>
        <?php endif; ?>
        <!-- Content Header (Page header) -->
        <div class="content-header mx-2">
            <div class="container-fluid mt-2" style="background-color: #ffffff;padding: 34px 34px">
                <div class="row mb-3 mt-3">
                    <div class="col-lg-12">
                        <h3>Welcome <?php echo e(Auth::user()->seller_first_name); ?>! Thanks for with us.</h3>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box" style="background-color: #007bff">
                            <div class="inner">
                                <h3>
                                    <i class="fas fa-shopping-bag"></i>
                                    <a style="color: white">



                                    </a>
                                </h3>
                                <p>New Orders</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-bag"></i>
                            </div>
                            <a href="<?php echo e(route('seller.allApprovedProducts')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box" style="background-color: #33BB82">
                            <div class="inner">
                                <h3>
                                    <i class="fas fa-truck-loading"></i>
                                    1
                                </h3>

                                <p>Order Accepted</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-stats-bars"></i>
                            </div>
                            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box" style="background-color: #FFC107">
                            <div class="inner">
                                <h3>
                                    <i class="fas fa-hourglass-start"></i>
                                    1
                                </h3>
                                <p>Pending Orders</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-person-add"></i>
                            </div>
                            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box" style="background-color: #f44336">
                            <div class="inner">
                                <h3>
                                    <i class="fas fa-window-close"></i>
                                    150
                                </h3>

                                <p>Cancel Orders</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-pie-graph"></i>
                            </div>
                            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <!-- ./col -->
                </div>
                <!-- /.row -->
                <!-- Main row -->










































































































































































































































































                <!-- /.row (main row) -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.layouts.seller_dashboard_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/seller/seller_dashboard/seller-profile.blade.php ENDPATH**/ ?>