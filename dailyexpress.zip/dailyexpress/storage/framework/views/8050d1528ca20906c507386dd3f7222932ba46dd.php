<?php $__env->startSection('sub-title', 'SEO Configurations'); ?>
<?php $__env->startSection('page-description', 'SEO Configurations'); ?>

<?php $__env->startSection('site-information-active', 'active'); ?>
<?php $__env->startSection('site-configuration-active', 'active'); ?>



<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">
        <div class="card new-admin">
            <div class="card-header">
                <strong><i class="fa fa-info-circle"></i> SEO</strong> Configurations
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('shop_info.seo')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group row">
                        <label for="google_seo" class="col-sm-3 col-form-label">Google Verification Code</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control <?php echo e($errors->has('google_seo') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('google_seo')); ?>"
                                   id="google_seo" name="google_seo" placeholder="Google Verification Code" autofocus>
                            <?php if($errors->has('google_seo')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('google_seo')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="bing_seo" class="col-sm-3 col-form-label">Bing Verification Code</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control <?php echo e($errors->has('bing_seo') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('bing_seo')); ?>"
                                   id="bing_seo" name="bing_seo" placeholder="Bing Verification Code">
                            <?php if($errors->has('bing_seo')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('bing_seo')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="yandex_seo" class="col-sm-3 col-form-label">Yandex Verification Code</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control <?php echo e($errors->has('yandex_seo') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('yandex_seo')); ?>"
                                   id="yandex_seo" name="yandex_seo" placeholder="Yandex Verification Code">
                            <?php if($errors->has('yandex_seo')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('yandex_seo')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="pinterest_seo" class="col-sm-3 col-form-label">Pinterest Verification Code</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control <?php echo e($errors->has('pinterest_seo') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('pinterest_seo')); ?>"
                                   id="pinterest_seo" name="pinterest_seo" placeholder="Pinterest Verification Code">
                            <?php if($errors->has('pinterest_seo')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('pinterest_seo')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-9 offset-sm-3">
                            <button class="btn btn-success" type="submit">Update SEO</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/site-information/seo.blade.php ENDPATH**/ ?>