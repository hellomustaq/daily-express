<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> <?php echo e(getSiteBasic('site_title')); ?></title>

    
    <meta name="application-name" content="<?php echo e(getSiteBasic('site_title')); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
    <meta name="author" content="BD SOFT IT">
    <meta name="robots" content="index, follow">
    <meta name="copyright" <?php echo e(getSiteBasic('site_title')); ?>>
    <meta name="language" content="<?php echo e(app()->getLocale()); ?>">
    <meta name="Classification" content="E-Commerce">
    <meta name="designer" content="BD SOFT IT">
    <meta name="reply-to" content="support@bdsoftit.com">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    
    <?php echo $__env->yieldContent('og-meta'); ?>
    
    <meta name="google-site-verification" content="<?php echo e(getSiteBasic('google_seo')); ?>">
    <meta name="msvalidate.01" content="<?php echo e(getSiteBasic('bing_seo')); ?>">
    <meta name="p:domain_verify" content="<?php echo e(getSiteBasic('pinterest_seo')); ?>">
    <meta name="yandex" content="<?php echo e(getSiteBasic('yandex_seo')); ?>">
    
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">

    <link rel="preload" href="<?php echo e(staticAsset('theme/css/app.css')); ?>" as="style">
    <?php if(!getSiteBasic('site_theme') || getSiteBasic('site_theme') === 'dark'): ?>
        <link rel="preload" href="<?php echo e(staticAsset('theme/css/dark.css')); ?>" as="style">
    <?php else: ?>
        <link rel="preload" href="<?php echo e(staticAsset('theme/css/light.css')); ?>" as="style">
    <?php endif; ?>
    <script src="<?php echo e(staticAsset('theme/js/manifest.js')); ?>" defer></script>
    <script src="<?php echo e(staticAsset('theme/js/vendor.js')); ?>" defer></script>
    <script src="<?php echo e(staticAsset('theme/js/app.js')); ?>" defer></script>

    <?php ($accent = (getSiteBasic('theme_accent')) ? getSiteBasic('theme_accent') : ((!getSiteBasic('site_theme') || getSiteBasic('site_theme') === 'dark') ? '#20a385' : '#ea000d')); ?>
    <?php ($txt = (getSiteBasic('theme_text') != null) ? getSiteBasic('theme_text') : '#262626'); ?>

    <style>
        :root {
            --accent-color: <?php echo e($accent); ?>;
            --txt-color: <?php echo e($txt); ?>;
        }
    </style>
    
    <link rel="stylesheet" href="<?php echo e(staticAsset('theme/css/app.css')); ?>">
    
    <?php if(!getSiteBasic('site_theme') || getSiteBasic('site_theme') == 'dark'): ?>
        <link rel="stylesheet" href="<?php echo e(staticAsset('theme/css/dark.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(staticAsset('theme/css/light.css')); ?>">
    <?php endif; ?>

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>

<?php ($logo = getSiteBasic('site_logo')); ?>
<?php ($title = getSiteBasic('site_title')); ?>
<?php ($mobile = getSiteBasic('site_mobile')); ?>

<div id="app">
    
    <header id="header">
        <div class="header-top">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-center text-lg-left d-none d-md-block">
                        <p class="welcome-text">
                            Call Center:
                            <a class="hvr-grow" href="tel:<?php echo e($mobile ? '+880' . $mobile : '+8801400883400'); ?>">
                                <?php echo e($mobile ? mobileNumber($mobile) : '(+880) 1400 883400'); ?>

                            </a>
                        </p>
                    </div>

                    <div class="col-lg-8">
                        <div class="top-nav text-center text-lg-right">
                            <ul>
                                <li class="top-wishlist">
                                    <a href="<?php echo e(route('account') . '#accountWishlist'); ?>" @click.prevent="changeAccountTab($event, '#accountWishlist')" v-tooltip.top-bottom="'<?php echo e(auth()->check() ? "See Your Wishlist" : "Login to see wishlist"); ?>'">
                                        <i class="icon ion-md-heart"></i> Wishlist <span v-if="user" v-html="'(' + wishlist.length + ')'"></span>
                                    </a>
                                </li>
                                
                                <?php if(auth()->guard()->guest()): ?>
                                    <li class="top-login">
                                        <a href="<?php echo e(route('login')); ?>" v-tooltip.top-bottom="'Click to Login'">
                                            <i class="icon ion-ios-log-in"></i> Login
                                        </a>
                                    </li>
                                    <li class="top-login">
                                        <a href="<?php echo e(route('franchise.register')); ?>">
                                            <i class="icon ion-md-wallet"></i> Do You Want to be Merchant?
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if(auth()->guard()->check()): ?>
                                    <li class="top-links">
                                        <a href="javascript:void(0)">
                                            <i class="icon ion-ios-person"></i> My Account <i class="icon ion-ios-arrow-down"></i>
                                        </a>
                                        <ul class="dropdown-links">
                                            <li>
                                                <a href="<?php echo e(route('account') . '#accountProfile'); ?>" @click.prevent="changeAccountTab($event, '#accountProfile')">Profile</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('account') . '#accountOrders'); ?>" @click.prevent="changeAccountTab($event, '#accountOrders')">Orders</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('checkout')); ?>">Checkout</a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                                    Logout
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                            </ul>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header-main">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3">
                        <div class="logo">
                            <a href="<?php echo e(route('index')); ?>" class="d-block text-center">
                                <?php if($logo && strlen($logo) > 10): ?>
                                    <img src="<?php echo e(imageToDataUrl(storage_path('uploads/' . $logo))); ?>" alt="<?php echo e($title); ?>">
                                <?php else: ?>
                                    <h3><?php echo e($title); ?></h3>
                                <?php endif; ?>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="header-middle">
                            <div class="search-container">
                                <form action="#" id="searchForm">
                                    <div class="search-box">
                                        <live-search></live-search>
                                        
                                    </div>
                                </form>
                            </div>

                            <div class="header-cart-wrapper" @click.prevent="toggleCart" v-tooltip.top-center="'Click to Open Cart'">
                                <a href="javascript:void(0)">
                                    <i class="icon ion-ios-cart"></i>
                                    <span v-html="cartWrapperHTML"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-xl-3 cat-menu-col">
                        <?php echo $__env->make('theme::partials.main-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <div class="col-lg-8 col-xl-9 head-menu-col">
                        <div class="header-bottom-menu">
                            <nav>
                                <ul>
                                    <li class="d-none d-sm-inline-block">
                                        <a href="<?php echo e(route('shop')); ?>">
                                            <i class="icon ion-md-home"></i> Shop
                                        </a>
                                    </li>

                                    <li>
                                        <a href="<?php echo e(route('about-us')); ?>">
                                            <i class="icon ion-md-information-circle"></i> About US
                                        </a>
                                    </li>

                                    

                                    <li>
                                        <a href="#" role="button" data-toggle="modal" data-target="#trackOrderModal">
                                            <i class="icon ion-md-locate"> </i> Track Order
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    

    
    <main id="main">
		<div class="breadcrumbs-area">
			<div class="container">
				<?php echo $__env->yieldContent('breadcrumb'); ?>
			</div>
		</div>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    

    
    <footer id="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <div class="footer-info mb-5 mb-md-0">
                            <a href="<?php echo e(route('index')); ?>" class="footer-logo">
                                <img src="<?php echo e(($logo && strlen($logo) > 0) ? imageToDataUrl(storage_path('uploads/' . $logo)) : 'https://via.placeholder.com/215x70'); ?>" alt="">
                            </a>
                            <div class="footer-contact">
                                <ul>
                                    <li>
                                        <i class="icon ion-ios-home"></i>
                                        <a href="<?php echo e(urldecode(getSiteBasic('map_address'))); ?>" target="_blank" v-tooltip.top-start="'View in Google Map'">
                                            <span><?php echo e(getSiteBasic('site_address')); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <i class="icon ion-ios-call"></i>
                                        <a href="tel:<?php echo e(mobileNumber($mobile)); ?>" v-tooltip.top-start="'Click to Call Helpline'">
                                            <span><?php echo e(mobileNumber($mobile)); ?></span>
                                        </a>
                                    </li>
                                    <li>
                                        <i class="icon ion-ios-mail"></i>
                                        <a href="mailto:<?php echo e(getSiteBasic('site_email')); ?>?subject=Feedback&body=Write Your Questions Here......" v-tooltip.top-start="'Click to Mail for Support'">
                                            <span><?php echo e(getSiteBasic('site_email')); ?></span>
                                        </a>

                                    </li>
                                </ul>
                            </div>
                            <div class="footer-social">
                                <ul>
                                    <li>
                                        <a href="<?php echo e(getSiteBasic('facebook_page')); ?>" target="_blank" v-tooltip.top-center="'View Facebook Page'" style="background-color: #1b78c6;">
                                            <i class="icon ion-logo-facebook"></i>
                                        </a>
                                        <div class="social-title">
                                            <p>Find Us</p>
                                            <h3>Facebook</h3>
                                        </div>
                                    </li>

                                    <li>
                                        <a href="<?php echo e(getSiteBasic('twitter_page')); ?>" target="_blank" v-tooltip.top-center="'View Twitter Page'" style="background-color: #00bff3;">
                                            <i class="icon ion-logo-twitter"></i>
                                        </a>
                                        <div class="social-title">
                                            <p>Follow Us</p>
                                            <h3>Twitter</h3>
                                        </div>
                                    </li>

                                    <li>
                                        <a href="<?php echo e(getSiteBasic('youtube_channel')); ?>" target="_blank" v-tooltip.top-center="'View Youtube Channel'" style="background-color: #f75a53;">
                                            <i class="icon ion-logo-youtube"></i>
                                        </a>
                                        <div class="social-title">
                                            <p>Subscribe</p>
                                            <h3>Youtube</h3>
                                        </div>
                                    </li>

                                    <li>
                                        <a href="<?php echo e(getSiteBasic('instagram_page')); ?>" target="_blank" v-tooltip.top-center="'View Instagram Page'" style="background-color: #f06b78;">
                                            <i class="icon ion-logo-instagram"></i>
                                        </a>
                                        <div class="social-title">
                                            <p>Follow Us</p>
                                            <h3>Instagram</h3>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-7">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="footer-links mb-5 mb-md-0">
                                    <h3>CUSTOMER SERVICE</h3>
                                    <div class="footer-menu">
                                        <ul>
                                            <li><a href="<?php echo e(route('shipping-and-returns')); ?>">Shipping & Returns</a></li>
                                            <li><a href="<?php echo e(route('delivery-information')); ?>">Delivery Information</a></li>
                                            <li><a href="<?php echo e(route('secure-shopping')); ?>"> Secure Shopping</a></li>
                                            <li><a href="#">International Shipping</a></li>
                                            <li><a href="#"> Affiliates/Franchise</a></li>
                                            <li><a href="<?php echo e(route('contact')); ?>"> Contact</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="footer-links">
                                    <h3>Information</h3>
                                    <div class="footer-menu">
                                        <ul>
                                            <li><a href="<?php echo e(route('about-us')); ?>">About Us</a></li>
                                            <li><a href="<?php echo e(route('privacy-policy')); ?>">Privacy Policy</a></li>
                                            <li><a href="#">Blog</a></li>
                                            <li><a href="#">Portfolio</a></li>
                                            <li><a href="<?php echo e(route('terms-and-conditions')); ?>">Terms & Conditions</a></li>
                                            <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="copyright text-center text-md-left mb-2 mb-md-0">
                            Copyright &copy; <?php echo e(date('Y')); ?> <a href="<?php echo e(route('index')); ?>"><?php echo e($title); ?></a>. All Rights Reserved.
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="credit text-center text-md-right">
                            Designed & Developed by: <a href="https://bdsoftit.com" target="_blank" title="A Creative Software Company">BD SOFT IT</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    

    
    <div class="modal fade" id="trackOrderModal" tabindex="-1" role="dialog" aria-labelledby="trackOrderModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="javascript:void(0)" class="text-center" @submit.prevent="trackOrder">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header w-100">
                        <h5 class="modal-title text-center w-100" id="trackOrderModalLabel">Track Order</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group text-center">
                            <label for="order_no">Enter You Order No</label>
                            <br>
                            <input v-model="orderTrackNo" type="text" class="form-control text-center" id="order_no" name="order_no" required autofocus>
                        </div>
                    </div>
                    <div class="modal-footer text-center d-block">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <shopping-cart
            :opened="cartOpen"
            @close="toggleCart">
    </shopping-cart>

    <div class="quickViewModalWrapper">
        <quick-view
                :product="quickViewProduct.product"
                :franchise="quickViewProduct.franchise"
                img-url="<?php echo e(imageCache('/', 'original')); ?>"
                @cart="addToCartWithOption"
                @wishlist="addToWishList"
                @close="closeQuickViewModal"
                v-if="quickViewProduct.product !== null">
        </quick-view>
    </div>

    <div class="loading-spinner" v-if="loading">
        <hash-loader
                class="custom-loader"
                color="<?php echo e($accent); ?>"
                :loading="loading"
                :size="50"
                :size-unit="'px'">
        </hash-loader>
    </div>

    <?php echo socialShareLinkGroup(
            ['facebook', 'google', 'twitter', 'pinterest', 'linkedin', 'reddit'],
            null, null, null,
            ['position' => 'fixed', 'float' => 'left', 'show' => 'vertical']
        ); ?>


</div>

<?php echo $__env->yieldContent('script'); ?>



</body>
</html>
<?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\theme/views/layouts/app.blade.php ENDPATH**/ ?>