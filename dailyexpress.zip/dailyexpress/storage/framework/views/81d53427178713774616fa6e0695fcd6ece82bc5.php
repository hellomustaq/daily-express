

<?php $__env->startSection('sub-title', 'Media Manager'); ?>
<?php $__env->startSection('page-description', 'View All Medias'); ?>

<?php $__env->startSection('media-active', 'active'); ?>


<?php $__env->startSection('admin-content'); ?>
    <rbt-media-manager directory="main" user_id="<?php echo e(auth('admin')->id()); ?>" url_prefix="/bs-mm-api" show_as="page"></rbt-media-manager>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/Franchise/resources/views/admin/media.blade.php ENDPATH**/ ?>