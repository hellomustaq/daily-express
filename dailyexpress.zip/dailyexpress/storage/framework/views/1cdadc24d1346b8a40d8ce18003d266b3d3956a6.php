

<?php $__env->startSection('title', $about->post_title . ' :: '); ?>
<?php $__env->startSection('description', getSiteBasic('site_description')); ?>
<?php $__env->startSection('keywords', getSiteBasic('site_keywords')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__env->startComponent('theme::components.breadcrumb', [
            'data'  => [
                //['url' => '#', 'title' => 'Shop']
            ],
            'active'   => $about->post_title
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .about-page {
            text-align: center;
        }
        .about-page img {
            margin: 0 auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="about-page py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <?php echo $about->post_description; ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/Franchise/theme/views/secure-shopping.blade.php ENDPATH**/ ?>