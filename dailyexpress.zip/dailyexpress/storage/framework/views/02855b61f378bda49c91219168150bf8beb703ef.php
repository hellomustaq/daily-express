<div class="main-sidebar-user">
    <div class="media">
        <?php if(auth('admin')->user()->img_url && strlen(auth('admin')->user()->img_url) > 10): ?>
            <img src="<?php echo e(imageCache(auth('admin')->user()->img_url, '200')); ?>" alt="<?php echo e(auth('admin')->user()->name); ?>" class="align-self-center img-fluid">
        <?php else: ?>
            <img src="<?php echo e(asset('assets/images/user.png')); ?>" alt="<?php echo e(auth('admin')->user()->name); ?>" class="align-self-center img-fluid">
        <?php endif; ?>
        <div class="media-body" :class="{'hide': mainSidebarToggled}">
            <h5><?php echo e(auth('admin')->user()->name); ?></h5>
            <p>
                <a href="<?php echo e(route('admin.profile')); ?>" title="Profile"><i class="fa fa-user"></i></a>
                <a href="<?php echo e(route('admin.profile.security')); ?>" title="Security"><i class="fa fa-cog"></i></a>
                <a href="<?php echo e(route('admin.logout')); ?>" title="Logout" onclick="event.preventDefault();
                                                             document.getElementById('logout-form').submit();">
                    <i class="fa fa-sign-out"></i>
                </a>
            </p>

        </div>
    </div>
</div>

<nav class="main-sidebar-nav">
    <ul class="nav flex-column">

        <li class="nav-item menu-header" :class="{'sr-only': mainSidebarToggled}">
            <div class="nav-link">
                Shop Management <span class="pull-right"><i class="fa fa-cubes"></i></span>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('dashboard-active'); ?>" href="<?php echo e(route('admin.home')); ?>">
                <i class="fa fa-tachometer" title="Dashboard"></i> <span :class="{'hide': mainSidebarToggled}">Dashboard</span>
            </a>
        </li>
        
        <li class="nav-item dropright">
            <a class="nav-link <?php echo $__env->yieldContent('orders-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-shopping-cart" title="Orders"></i>
                <span :class="{'hide': mainSidebarToggled}">Orders</span>
                <span class="badge badge-warning pending-orders-count" :class="{'hide': mainSidebarToggled}"><?php echo e(getOrderSummary()->pending); ?></span>
                <span class="pull-right"><i class="fa fa-angle-right"></i></span>
            </a>
            <div class="dropdown-menu">
                <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                    Orders
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-order')): ?>
                    <a href="<?php echo e(route('admin.orders.create')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-create-active'); ?>">Create New Order</a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.orders.pending')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-pending-active'); ?>">
                    Pending Orders <span class="badge badge-warning pending-orders-count"><?php echo e(getOrderSummary()->pending); ?></span>
                </a>
                <?php if(!auth('admin')->user()->isShipper()): ?>
                    <a href="<?php echo e(route('admin.orders.confirmed')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-confirmed-active'); ?>">Confirmed Orders</a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.orders.delivered')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-delivered-active'); ?>">Delivered Orders</a>
                <a href="<?php echo e(route('admin.orders.canceled')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-canceled-active'); ?>">Canceled Orders</a>
                <?php if(!auth('admin')->user()->isShipper() && !auth('admin')->user()->isFranchise()): ?>
                    <hr style="margin: 5px 24px; border-color: #464646;">
                    <a href="<?php echo e(route('admin.orders.for-franchise')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-for-franchise-active'); ?>">Orders For Franchise</a>
                    <a href="<?php echo e(route('admin.orders.by-franchise')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-by-franchise-active'); ?>">Orders By Franchise</a>
                    <hr style="margin: 5px 24px; border-color: #464646;">
                <?php endif; ?>
                <a href="<?php echo e(route('admin.orders')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-all-active'); ?>">All Orders</a>
                <?php if(auth('admin')->user()->isFranchise()): ?>
                    <hr style="margin: 5px 24px; border-color: #464646;">
                    <a href="<?php echo e(route('admin.orders.by-franchise')); ?>" class="dropdown-item <?php echo $__env->yieldContent('orders-by-franchise-active'); ?>">Orders By Me</a>
                <?php endif; ?>
            </div>
        </li>
        
        <?php if(auth('admin')->user()->can('view-product')): ?>
            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('products-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-product-hunt" title="Products"></i>
                    <span :class="{'hide': mainSidebarToggled}">Products</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Products
                    </div>

                    <?php if(!auth('admin')->user()->isFranchise()): ?>
                        <a href="<?php echo e(route('admin.products.create')); ?>" class="dropdown-item <?php echo $__env->yieldContent('products-new-active'); ?>">Add New Product</a>
                        <a href="<?php echo e(route('admin.products.returned')); ?>" class="dropdown-item <?php echo $__env->yieldContent('products-returned-active'); ?>">Returned Products</a>
                        <a href="<?php echo e(route('admin.products.damaged')); ?>" class="dropdown-item <?php echo $__env->yieldContent('products-damaged-active'); ?>">Damaged Products</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.products.all')); ?>" class="dropdown-item <?php echo $__env->yieldContent('products-all-active'); ?>">All Products</a>
                    <?php if(auth('admin')->user()->isFranchise()): ?>
                        <a href="<?php echo e(route('admin.products.franchise')); ?>" class="dropdown-item <?php echo $__env->yieldContent('products-own-active'); ?>">Own Products</a>

                        <a href="<?php echo e(route('admin.products.create')); ?>" class="dropdown-item <?php echo $__env->yieldContent('products-new-active'); ?>">Add New Product</a>


                    <?php endif; ?>
                </div>
            </li>
        <?php endif; ?>
        
        <?php if(!auth('admin')->user()->isShipper() && !auth('admin')->user()->isFranchise()): ?>
            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('categories-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-sitemap" title="Categories"></i>
                    <span :class="{'hide': mainSidebarToggled}">Categories</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Categories
                    </div>
                    <?php if(Auth::guard('admin')->user()->isSuperAdmin() || Auth::guard('admin')->user()->isAdmin()): ?>
                        <a href="<?php echo e(route('admin.categories.create')); ?>" class="dropdown-item <?php echo $__env->yieldContent('categories-new-active'); ?>">Add New Category</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.categories')); ?>" class="dropdown-item <?php echo $__env->yieldContent('categories-all-active'); ?>">All Categories</a>
                </div>
            </li>
        <?php endif; ?>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-brand')): ?>
            <?php if(!auth('admin')->user()->isFranchise()): ?>
                <li class="nav-item dropright">
                    <a class="nav-link <?php echo $__env->yieldContent('brand-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-superpowers" title="Brands"> </i>
                        <span :class="{'hide': mainSidebarToggled}">Brands</span>
                        <span class="pull-right"><i class="fa fa-angle-right"> </i></span>
                    </a>
                    <div class="dropdown-menu">
                        <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                            Brands
                        </div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-brand')): ?>
                            <a href="<?php echo e(route('admin.brands.create')); ?>" class="dropdown-item <?php echo $__env->yieldContent('brand-new-active'); ?>">Add New Brand</a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admins.brands')); ?>" class="dropdown-item <?php echo $__env->yieldContent('brand-all-active'); ?>">All Brands</a>
                    </div>
                </li>
            <?php endif; ?>
        <?php endif; ?>
        <?php if(auth('admin')->user()->isAlpha() || auth('admin')->user()->isSuperAdmin()): ?>
             

















             
            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('shippers-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-paper-plane" title="Shippers"></i>
                    <span :class="{'hide': mainSidebarToggled}">Shippers</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Shippers
                    </div>

                    <a href="<?php echo e(route('admin.shipper.create')); ?>" class="dropdown-item <?php echo $__env->yieldContent('shippers-new-active'); ?>">Add New Shipper</a>
                    <a href="<?php echo e(route('admin.shipper.all')); ?>" class="dropdown-item <?php echo $__env->yieldContent('shippers-all-active'); ?>">All Shippers</a>
                </div>
            </li>
            
            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('shipping-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-truck" title="Shipping Methods"> </i>
                    <span :class="{'hide': mainSidebarToggled}">Shipping Methods</span>
                    <span class="pull-right"><i class="fa fa-angle-right"> </i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Shipping Methods
                    </div>

                    <a href="<?php echo e(route('admin.shipping.add')); ?>" class="dropdown-item <?php echo $__env->yieldContent('shipping-new-active'); ?>">Add New Method</a>
                    <a href="<?php echo e(route('admin.shipping')); ?>" class="dropdown-item <?php echo $__env->yieldContent('shipping-all-active'); ?>">All Shipping Methods</a>
                </div>
            </li>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-customers')): ?>
                <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('customers-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-user-secret" title="Customers"></i>
                    <span :class="{'hide': mainSidebarToggled}">Customers</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Customers
                    </div>

                    <a href="<?php echo e(route('admin.customers.add')); ?>" class="dropdown-item <?php echo $__env->yieldContent('customers-new-active'); ?>">Add New Customers</a>
                    <a href="<?php echo e(route('admin.customers')); ?>" class="dropdown-item <?php echo $__env->yieldContent('customers-all-active'); ?>">All Customers</a>
                </div>
            </li>
            <?php endif; ?>
            
            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('franchise-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-handshake-o" title="Franchise"></i>
                    <span :class="{'hide': mainSidebarToggled}">Merchant</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Merchant
                    </div>


                    <a href="<?php echo e(route('admin.franchise-control.all')); ?>" class="dropdown-item <?php echo $__env->yieldContent('franchise-all-active'); ?>">All Merchant</a>
                </div>
            </li>


            















        <?php endif; ?>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-preferences')): ?>
            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('shop-preferences-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-wrench" title="Shop Preferences"></i>
                    <span :class="{'hide': mainSidebarToggled}">Shop Preferences</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Shop Preferences
                    </div>

                    <a href="<?php echo e(route('admin.shop_preferences.delivery_locations')); ?>" class="dropdown-item <?php echo $__env->yieldContent('shop-preferences-locations-active'); ?>">Delivery Locations</a>
                    <a href="<?php echo e(route('admin.shop_preferences.delivery_schedules')); ?>" class="dropdown-item <?php echo $__env->yieldContent('shop-preferences-schedules-active'); ?>">Delivery Schedules</a>
                </div>
            </li>
        <?php endif; ?>
        
        <?php if(auth('admin')->user()->isAlpha() || auth('admin')->user()->isAdmin() || auth('admin')->user()->isSuperAdmin() || auth('admin')->user()->isManager()): ?>
            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('marketing-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-sellsy" title="Marketing"></i>
                    <span :class="{'hide': mainSidebarToggled}">Marketing</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Marketing
                    </div>
                    <a href="<?php echo e(route('admin.coupon.index')); ?>" class="dropdown-item <?php echo $__env->yieldContent('marketing-coupons-active'); ?>">Coupons</a>





                </div>
            </li>
        <?php endif; ?>
        
        <?php if(auth('admin')->user()->isAlpha() || auth('admin')->user()->isAdmin() ||auth('admin')->user()->isSuperAdmin()): ?>
            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('ads-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-audio-description" title="Product Reviews"></i>
                    <span :class="{'hide': mainSidebarToggled}">Banner Ads</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Banner Ads
                    </div>

                    <a href="<?php echo e(route('admin.ads.sliders')); ?>" class="dropdown-item <?php echo $__env->yieldContent('ads-sliders-active'); ?>">
                        Home Sliders
                    </a>
                    <a href="<?php echo e(route('admin.ads.index_banners')); ?>" class="dropdown-item <?php echo $__env->yieldContent('ads-index-banner-active'); ?>">
                        Index Page Banners
                    </a>
                    <a href="<?php echo e(route('admin.ads.category_banners')); ?>" class="dropdown-item <?php echo $__env->yieldContent('ads-category-banner-active'); ?>">
                        Category Banners
                    </a>
                    <a href="<?php echo e(route('admin.ads.sidebar_banner')); ?>" class="dropdown-item <?php echo $__env->yieldContent('ads-sidebar-active'); ?>">Sidebar Ads</a>

                </div>
            </li>
        <?php endif; ?>
        





























        <?php if(auth('admin')->user()->isAdmin() || auth('admin')->user()->isSuperAdmin()): ?>
            <li class="nav-item menu-header" :class="{'sr-only': mainSidebarToggled}">
                <div class="nav-link">
                    Web Contents <span class="pull-right"><i class="fa fa-globe"></i></span>
                </div>
            </li>



































            <li class="nav-item">
                <a class="nav-link <?php echo $__env->yieldContent('pages-active'); ?>" href="<?php echo e(route('admin.pages')); ?>">
                    <i class="fa fa-file-text-o" title="Static Pages"></i> <span :class="{'hide': mainSidebarToggled}">Pages</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo $__env->yieldContent('media-active'); ?>" href="<?php echo e(route('admin.media')); ?>">
                    <i class="fa fa-film" title="Media Manager"></i> <span :class="{'hide': mainSidebarToggled}">Media Manager</span>
                </a>
            </li>
        <?php endif; ?>

        
        <li class="nav-item menu-header" :class="{'sr-only': mainSidebarToggled}">
            <div class="nav-link">
                User Settings <span class="pull-right"><i class="fa fa-cogs"></i></span>
            </div>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('profile-details-active'); ?>" href="<?php echo e(route('admin.profile')); ?>">
                <i class="fa fa-user-circle-o" title="Personal Details"></i> <span :class="{'hide': mainSidebarToggled}">Personal Details</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo $__env->yieldContent('profile-security-active'); ?>" href="<?php echo e(route('admin.profile.security')); ?>">
                <i class="fa fa-shield" title="Account Security"></i> <span :class="{'hide': mainSidebarToggled}">Account Security</span>
            </a>
        </li>

        <?php if(auth('admin')->user()->isAdmin() || auth('admin')->user()->isSuperAdmin()): ?>

            
            <li class="nav-item menu-header" :class="{'sr-only': mainSidebarToggled}">
                <div class="nav-link">
                    Admin Controls <span class="pull-right"><i class="fa fa-sliders"></i></span>
                </div>
            </li>

            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('site-information-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-info-circle" title="Site Information"></i>
                    <span :class="{'hide': mainSidebarToggled}">Site Information</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Shop Information
                    </div>

                    <a href="<?php echo e(route('shop_info.index')); ?>" class="dropdown-item <?php echo $__env->yieldContent('site-details-active'); ?>">Shop Details</a>
                    <a href="<?php echo e(route('shop_info.config')); ?>" class="dropdown-item <?php echo $__env->yieldContent('site-config-active'); ?>">Shop Configuration</a>
                    <a href="<?php echo e(route('shop_info.seo')); ?>" class="dropdown-item <?php echo $__env->yieldContent('site-configuration-active'); ?>">SEO Configuration</a>
                    <a href="<?php echo e(route('shop_info.social')); ?>" class="dropdown-item <?php echo $__env->yieldContent('site-social-active'); ?>">Social Information</a>
                    
                </div>
            </li>

            <li class="nav-item dropright">
                <a class="nav-link <?php echo $__env->yieldContent('admins-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fa fa-users" title="Admins" style="font-size: 13px;"></i>
                    <span :class="{'hide': mainSidebarToggled}">Admins</span>
                    <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                </a>
                <div class="dropdown-menu">
                    <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                        Admins
                    </div>

                    <a href="<?php echo e(route('admin.admins.create')); ?>" class="dropdown-item <?php echo $__env->yieldContent('admins-new-active'); ?>">Add New Admin</a>
                    <a href="<?php echo e(route('admin.admins.all')); ?>" class="dropdown-item <?php echo $__env->yieldContent('admins-all-active'); ?>">All Admins</a>
                </div>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('control-api')): ?>
                <li class="nav-item dropright">
                    <a class="nav-link <?php echo $__env->yieldContent('api-active'); ?> dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-database" title="Api Agents"></i>
                        <span :class="{'hide': mainSidebarToggled}">Api Agents</span>
                        <span class="pull-right"><i class="fa fa-angle-right"></i></span>
                    </a>
                    <div class="dropdown-menu">
                        <div class="dropdown-item hidden-menu-title" v-if="mainSidebarToggled">
                            Api Agents
                        </div>

                        <a href="<?php echo e(route('admin.api_agent.add')); ?>" class="dropdown-item <?php echo $__env->yieldContent('api-new-active'); ?>">Add new</a>
                        <a href="<?php echo e(route('admin.api_agent')); ?>" class="dropdown-item <?php echo $__env->yieldContent('api-all-active'); ?>">All Agents</a>
                    </div>
                </li>
            <?php endif; ?>

            <?php if(auth('admin')->user()->isAlpha()): ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo $__env->yieldContent('media-active'); ?>" href="<?php echo e(route('admin.features')); ?>">
                        <i class="fa fa-universal-access" title="Media Manager"></i> <span :class="{'hide': mainSidebarToggled}">Active Features</span>
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/partials/main-sidebar.blade.php ENDPATH**/ ?>