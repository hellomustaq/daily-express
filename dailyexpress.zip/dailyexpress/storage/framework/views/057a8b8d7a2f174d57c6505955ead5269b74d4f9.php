<?php $__env->startSection('sub-title', 'Shop Preferences (Delivery Locations)'); ?>
<?php $__env->startSection('page-description', 'Manage Shop Delivery Locations'); ?>

<?php $__env->startSection('shop-preferences-active', 'active'); ?>
<?php $__env->startSection('shop-preferences-locations-active', 'active'); ?>



<?php $__env->startSection('admin-content'); ?>
    <div class="admin-shop-preferences">
        <div class="admin-content-header-summary">
            <div class="row">

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header">Total <strong>States</strong></h5>
                        <div class="card-body">
                            <span><?php echo e($summary->states); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header">Total <strong>Cities</strong></h5>
                        <div class="card-body">
                            <span><?php echo e($summary->cities); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header rbt-bg-main">Total <strong>Areas</strong></h5>
                        <div class="card-body rbt-text-main">
                            <span><?php echo e($summary->areas); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header rbt-bg-main">Selected <strong>Areas</strong></h5>
                        <div class="card-body rbt-text-main">
                            <span><?php echo e($summary->selected); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <delivery-locations api_url="<?php echo e(route('admin.api.shop_preferences.locations')); ?>"></delivery-locations>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/shop-preferences/locations.blade.php ENDPATH**/ ?>