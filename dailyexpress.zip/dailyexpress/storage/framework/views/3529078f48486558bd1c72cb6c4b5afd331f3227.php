<?php $__env->startSection('sub-title', 'Add New Shipper'); ?>
<?php $__env->startSection('page-description', 'Add New Shipper'); ?>

<?php $__env->startSection('shippers-active', 'active'); ?>
<?php $__env->startSection('shippers-new-active', 'active'); ?>



<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">

        <create-shipper api="<?php echo e(route('admin.api.shipper.create')); ?>"></create-shipper>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/shippers/create.blade.php ENDPATH**/ ?>