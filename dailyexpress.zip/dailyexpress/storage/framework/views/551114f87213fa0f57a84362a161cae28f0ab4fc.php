<?php $__env->startSection('sub-title', 'Orders For Franchise'); ?>
<?php $__env->startSection('page-description', 'View all Orders For Franchise.'); ?>

<?php $__env->startSection('orders-active', 'active'); ?>
<?php $__env->startSection('orders-for-franchise-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-orders">
        <?php if(Session::has('status')): ?>
            <div class="alert alert-success" role="alert">
                <span class="alert-icon">
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"> </i>
                </span>
                <br>
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>

        <div class="admin-content-header-summary">
            <div class="row">
                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header rbt-bg-main"><strong>Orders</strong> Pending</h5>
                        <div class="card-body rbt-text-main">
                            <span><?php echo e(getOrderSummary()->pending); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Orders</strong> Today</h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->today; ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Orders</strong> This Month</h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->this_month; ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Orders</strong> Last Month</h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->last_month; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="admin-orders-table">

            <order-data-table
                    api_url="<?php echo e(route('admin.api.orders', ['type' => 'for-franchise'])); ?>"
                    order_type="For Franchise">
            </order-data-table>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/orders/for_franchise.blade.php ENDPATH**/ ?>