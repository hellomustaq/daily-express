<?php $__env->startSection('sub-title', 'Edit Index Page Sliders'); ?>
<?php $__env->startSection('page-description', 'Edit Index Page Sliders'); ?>

<?php $__env->startSection('ads-active', 'active'); ?>
<?php $__env->startSection('ads-index-banner-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-ads">
        <promotional-banner
                page-title="Page Middle Banners"
                img-placeholder="https://via.placeholder.com/630x175?text=630x175+px"
                api="<?php echo e(route('admin.api.ads.index_banners')); ?>">
        </promotional-banner>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/ads/index_banners.blade.php ENDPATH**/ ?>