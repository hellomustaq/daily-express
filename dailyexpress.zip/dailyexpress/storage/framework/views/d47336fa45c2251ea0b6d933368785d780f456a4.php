<div class="control-sidebar-content" :class="{ 'show': controlSidebarToggled }">
    <?php if(auth('admin')->user()->isSuperAdmin() || auth('admin')->user()->isAdmin()): ?>
        <div class="card section-card">
            <h3 class="card-header">Theme Color</h3>
            <div class="card-body">
                <form action="<?php echo e(route('shop_info.front_theme')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <?php ($site_theme = getSiteBasic('site_theme')); ?>
                        <label for="siteTheme" style="font-size: 14px; font-weight: 600;">Shop Theme: </label> &nbsp;&nbsp;&nbsp;
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" id="customRadioInline1" name="site_theme" value="light" class="custom-control-input" <?php if($site_theme === 'light'): ?> checked <?php endif; ?>>
                            <label style="font-size: 13px; font-weight: 600;" class="custom-control-label" for="customRadioInline1">Light</label>
                        </div>
                        <div class="custom-control custom-radio custom-control-inline">
                            <input type="radio" id="customRadioInline2" name="site_theme" value="dark" class="custom-control-input"  <?php if($site_theme === 'dark'): ?> checked <?php endif; ?>>
                            <label style="font-size: 13px; font-weight: 600;" class="custom-control-label" for="customRadioInline2">Dark</label>
                        </div>
                    </div>

                    <div class="form-group">
                        <?php ($theme_accent = getSiteBasic('theme_accent') ? getSiteBasic('theme_accent') : '#ea000d'); ?>
                        <label for="bgColor" style="font-size: 14px; font-weight: 600;">Theme Accent:</label> &nbsp;&nbsp;&nbsp;
                        <input type="color" id="bgColor" class="form-control d-inline-block" name="theme_accent" value="<?php echo e($theme_accent); ?>"
                               style="width: 50px; border: 0; background: transparent;padding: 0; height: 25px; cursor: pointer;" title="Click to change the color">
                        <small style="margin-top: -5px;" class="form-text text-muted">Click on the color box to change!</small>
                    </div>

                   

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary" style="margin-top: 10px; padding: 2px 8px; font-size: 14px;">
                            Update Theme
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <?php if(auth('admin')->user()->isFranchise()): ?>
        <shopping-cart
                @close="toggleControlSidebar">
        </shopping-cart>
    <?php endif; ?>





















































































































</div>

<div class="control-sidebar-back" :class="{ 'show': controlSidebarToggled }"></div>
<?php /**PATH /home/dailyexp/Franchise/resources/views/admin/partials/control-sidebar.blade.php ENDPATH**/ ?>