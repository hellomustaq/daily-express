

<?php $__env->startSection('sub-title', 'Shop Admins'); ?>
<?php $__env->startSection('page-description', 'All Shop Admins'); ?>

<?php $__env->startSection('admins-active', 'active'); ?>
<?php $__env->startSection('admins-all-active', 'active'); ?>

<?php $__env->startSection('header-action'); ?>
    <ul class="nav justify-content-end">
        <li class="nav-item text-center">
            <a class="nav-link btn btn-light" href="<?php echo e(route('admin.admins.create')); ?>">
                <i class="fa fa-plus"></i>
                <span class="d-none d-sm-block">Create Admin</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">

        <?php if(Session::has('status')): ?>
            <div class="alert alert-info text-center" role="alert">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <strong><i class="fa fa-users"></i> All</strong> Admins
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Mobile</th>
                                <th scope="col">Role</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($admin->email !== 'bdsoftit@email.com'): ?>
                                    <tr>
                                        <th scope="row">
                                            <a href="<?php echo e(route('admin.admins.single', ['id' => $admin->id])); ?>"><?php echo e($admin->name); ?></a>
                                        </th>
                                        <td><?php echo e($admin->email); ?></td>
                                        <td><?php echo e($admin->mobile_primary); ?></td>
                                        <td><?php echo e($admin->role->ar_title); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('admin.admins.single', ['id' => $admin->id])); ?>" class="btn btn-info text-white" title="View"><i class="fa fa-eye"></i></a>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-admin')): ?>
                                                <a href="<?php echo e(route('admin.admins.edit', ['id' => $admin->id])); ?>" class="btn btn-warning text-white" title="Edit"><i class="fa fa-pencil"></i></a>
                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn btn-danger text-white"  title="Delete" data-toggle="modal" data-target="#deleteModal<?php echo e($admin->id); ?>">
                                                    <i class="fa fa-trash"></i>
                                                </button>

                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal<?php echo e($admin->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel">Delete Admin</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure want to remove "<?php echo e($admin->name); ?>" as a <strong><?php echo e($admin->role->ar_title); ?></strong>?
                                                            </div>
                                                            <div class="modal-footer">
                                                                <form action="<?php echo e(route('admin.admins.delete')); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <input type="hidden" name="id" value="<?php echo e($admin->id); ?>">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                                    <button type="submit" class="btn btn-danger">Confirm</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/admin-controls/index.blade.php ENDPATH**/ ?>