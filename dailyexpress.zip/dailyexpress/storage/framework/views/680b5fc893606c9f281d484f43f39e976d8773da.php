<?php $__env->startSection('sub-title', 'Account Security'); ?>
<?php $__env->startSection('page-description', 'account security'); ?>

<?php $__env->startSection('dashboard-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">
        <div class="card new-admin">
            <div class="card-header">
                <strong><i class="fa fa-key"></i> Update</strong> Password
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.profile.security')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group row">
                        <label for="recipient-password-old" class="col-form-label col-md-3">Old Password: <span class="red">*</span></label>
                        <div class="col-md-9">
                            <input type="password" class="form-control <?php if ($errors->has('old_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('old_password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="recipient-password-old" name="old_password" required>
                            <?php if ($errors->has('old_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('old_password'); ?>
                            <span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="recipient-password" class="col-form-label col-md-3">New Password: <span class="red">*</span></label>
                        <div class="col-md-9">
                            <input type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="recipient-password" name="password" required>
                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                            <span class="invalid-feedback" role="alert">
										<strong><?php echo e($message); ?></strong>
									</span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="recipient-password-confirm" class="col-form-label col-md-3">Confirm New Password: <span class="red">*</span></label>
                        <div class="col-md-9">
                            <input type="password" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="recipient-password-confirm" name="password_confirmation" required>
                        </div>
                    </div>
                    <div class="form-group row mt-5">
                        <div class="col-md-9 offset-md-3">
                            <button type="submit" class="btn btn-success"> Update Password</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/profile/account_security.blade.php ENDPATH**/ ?>