<?php $__env->startSection('title', 'Reset Password :: '); ?>
<?php $__env->startSection('description', getSiteBasic('site_description')); ?>
<?php $__env->startSection('keywords', getSiteBasic('site_keywords')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__env->startComponent('theme::components.breadcrumb', [
            'data'  => [
                //['url' => '#', 'title' => 'Shop']
            ],
            'active'   => 'Reset Password'
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="auth-view">
        <div class="container my-3 my-md-5">
                <div class="row justify-content-center">

                    <div class="col-12 col-lg-10 px-0">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 col-lg-5" style="background-color: #1b1b1b;">
                        <div class="login-side">
                            <h3 class="d-none d-md-block">Shop With Confidence</h3>
                            <img src="<?php echo e(asset("images/shop_circle.png")); ?>" alt="" class="mw-100 d-none d-md-block hvr-grow-rotate">

                            <h4>
                                Get Started
                            </h4>

                            <span class="d-block">with</span>

                            <a href="<?php echo e(route('login.social', ['driver' => 'facebook'])); ?>" v-tooltip.top-bottom="'Login With Facebook'"
                               class="btn btn-light hvr-grow-rotate" style="background-color: #365dad;">
                                <i class="icon ion-logo-facebook"></i>
                            </a>
                            <a href="<?php echo e(route('login.social', ['driver' => 'google'])); ?>" v-tooltip.top-bottom="'Login With Google+'"
                               class="btn btn-light hvr-grow-rotate" style="background-color: #dd4e40;">
                                <i class="icon ion-logo-googleplus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-5" style="border: 2px solid #1b1b1b;">
                        <div class="card bsoft-card">
                            <div class="card-header text-center"><?php echo e(__('Reset Password')); ?></div>

                            <div class="card-body">
                                <form method="POST" action="<?php echo e(route('password.email')); ?>" id="password-email">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label for="email" class="sr-only">Email/Mobile</label>
                                        <div class="input-group <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon2">
                                                <i class="icon ion-ios-contact hvr-grow"></i>
                                            </span>
                                            </div>
                                            <input type="text" name="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('email')); ?>"
                                                   placeholder="Email or Mobile Number" aria-label="Email" aria-describedby="basic-addon2" id="email" required autofocus>
                                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group secured-btn text-center">
                                        
                                        <?php echo NoCaptcha::renderJs(); ?>

                                        <?php echo NoCaptcha::displaySubmit('password-email', 'Send Password Reset Request', ['data-theme' => 'dark']); ?>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/Franchise/theme/views/auth/passwords/email.blade.php ENDPATH**/ ?>