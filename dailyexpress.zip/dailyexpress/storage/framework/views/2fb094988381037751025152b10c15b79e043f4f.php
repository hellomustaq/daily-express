<?php echo e($slot); ?>

<?php /**PATH /home/dailyexp/Franchise/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>