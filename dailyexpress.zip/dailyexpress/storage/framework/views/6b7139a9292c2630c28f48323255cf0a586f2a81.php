<?php $__env->startSection('content'); ?>
    <div class="reset-password-box">
        <div class="card">
            <div class="card-header"><?php echo e(__('Reset Password')); ?></div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.password.request')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="token" value="<?php echo e($token); ?>">

                    <div class="form-group">
                        <label for="email" class="sr-only"><?php echo e(__('E-Mail Address')); ?></label>
                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Your Email" name="email" value="<?php echo e($email ?? old('email')); ?>" required autofocus>

                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="password" class="sr-only"><?php echo e(__('Password')); ?></label>
                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Password" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="password-confirm" class="sr-only"><?php echo e(__('Confirm Password')); ?></label>
                        <input id="password-confirm" type="password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" placeholder="Repeat Password" name="password_confirmation" required>

                        <?php if($errors->has('password_confirmation')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Reset Password')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/auth/passwords/reset.blade.php ENDPATH**/ ?>