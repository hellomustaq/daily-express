<?php $__env->startSection('title', 'Affiliate or Franchise Register :: '); ?>
<?php $__env->startSection('description', 'Register as a reseller.'); ?>
<?php $__env->startSection('keywords', 'affiliate, franchise, reseller'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__env->startComponent('theme::components.breadcrumb', [
			'data'  => [
				//['url' => '#', 'title' => 'Shop']
			],
			'active'   => 'Merchandise'
		]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="affiliate-page">
        <franchise-register> </franchise-register>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\theme/views/franchise.blade.php ENDPATH**/ ?>