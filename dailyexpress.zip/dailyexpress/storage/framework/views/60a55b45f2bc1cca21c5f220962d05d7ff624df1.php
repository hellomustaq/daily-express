<?php $__env->startSection('sub-title', 'Shop Shippers'); ?>
<?php $__env->startSection('page-description', 'All Shop Shippers'); ?>

<?php $__env->startSection('shippers-active', 'active'); ?>
<?php $__env->startSection('shipper-all-active', 'active'); ?>

<?php $__env->startSection('header-action'); ?>
    <ul class="nav justify-content-end">
        <li class="nav-item text-center">
            <a class="nav-link btn btn-light" href="<?php echo e(route('admin.shipper.create')); ?>">
                <i class="fa fa-plus"></i>
                <span class="d-none d-sm-block">Create Shipper</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">

        <?php if(Session::has('status')): ?>
            <div class="alert alert-info text-center" role="alert">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <strong><i class="fa fa-users"></i> All</strong> Shippers
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Mobile</th>
                                <th scope="col">Address</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($admin->shipper_name); ?></th>
                                    <td><?php echo e($admin->shipper_email); ?></td>
                                    <td><?php echo e($admin->shipper_phone); ?></td>
                                    <td><?php echo e($admin->shipper_address); ?></td>
                                    <td class="text-center">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-admin')): ?>
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-danger text-white"  title="Delete" data-toggle="modal" data-target="#deleteModal<?php echo e($admin->shipper_id); ?>">
                                                <i class="fa fa-trash"></i>
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="deleteModal<?php echo e($admin->shipper_id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="deleteModalLabel">Delete Shipper</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Are you sure want to remove "<?php echo e($admin->shipper_name); ?>" as a <strong>Shipper</strong>?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form action="<?php echo e(route('admin.shipper.delete')); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <input type="hidden" name="id" value="<?php echo e($admin->shipper_id); ?>">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                                <button type="submit" class="btn btn-danger">Confirm</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/shippers/index.blade.php ENDPATH**/ ?>