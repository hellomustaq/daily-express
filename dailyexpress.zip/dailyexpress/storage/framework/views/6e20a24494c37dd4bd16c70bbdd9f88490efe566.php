<?php $__env->startSection('sub-title', 'All Product Brands'); ?>
<?php $__env->startSection('page-description', 'All Product Brands'); ?>

<?php $__env->startSection('brand-active', 'active'); ?>
<?php $__env->startSection('brand-all-active', 'active'); ?>


<?php $__env->startSection('admin-content'); ?>
    <div class="rbt-product-brands">
        <product-brand-data-table api_url="<?php echo e(route('admin.api.brands.all')); ?>"></product-brand-data-table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/product-brands/index.blade.php ENDPATH**/ ?>