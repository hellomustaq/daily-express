<?php $__env->startSection('sub-title', 'Damaged Products'); ?>
<?php $__env->startSection('page-description', 'View All Damaged Products'); ?>

<?php $__env->startSection('products-active', 'active'); ?>
<?php $__env->startSection('products-damaged-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-products">
        
        <div class="admin-content-header-summary">
            <div class="row">
                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header rbt-bg-main"><strong>Featured</strong> Products</h5>
                        <div class="card-body rbt-text-main">
                            <span></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Out of</strong> Stock</h5>
                        <div class="card-body">
                            <span></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Inactive</strong> Products</h5>
                        <div class="card-body">
                            <span></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Total</strong> Products</h5>
                        <div class="card-body">
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/products/damaged.blade.php ENDPATH**/ ?>