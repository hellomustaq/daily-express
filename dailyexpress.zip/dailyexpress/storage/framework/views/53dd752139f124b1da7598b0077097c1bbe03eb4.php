<?php $__env->startSection('sub-title', 'Customers Details'); ?>
<?php $__env->startSection('page-description', 'Customers Details'); ?>

<?php $__env->startSection('customers-active', 'active'); ?>
<?php $__env->startSection('customers-all-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
	<div class="customers-view">

		<?php if(isset($notFound)): ?>
			<div class="alert alert-danger text-center py-5" role="alert">
				<h5 class="font-weight-bold"><?php echo e($notFound); ?></h5>
			</div>
		<?php else: ?>
			<div class="card">
				<div class="card-header">
					<strong><i class="fa fa-user"> </i> Customer's</strong> Details
				</div>
				<div class="card-body">
					<div class="row justify-content-center">
						<div class="col-xl-5">
							<div class="customers-details customers-wrapper text-center">
								<?php if($client->img_url && strlen($client->img_url) > 7): ?>
									<img src="<?php echo e(staticAsset($client->img_url)); ?>" alt="<?php echo e($client->full_name); ?>">
								<?php else: ?>
									<img src="<?php echo e(staticAsset('images/default_male.png')); ?>" alt="<?php echo e($client->full_name); ?>">
								<?php endif; ?>

								<h5> <?php echo e($client->full_name); ?> </h5>
								<hr>
									<table class="table table-borderless text-left">
										<tbody>
											<tr>
												<th scope="row">Email</th>
												<td><?php echo e($client->email); ?></td>
											</tr>
											<tr>
												<th scope="row">Mobile</th>
												<td><?php echo e($client->mobile ? mobileNumber($client->mobile) : ''); ?></td>
											</tr>
											<tr>
												<th scope="row">Mobile Secondary</th>
												<td><?php echo e($client->mobile_secondary ? mobileNumber($client->mobile_secondary) : ''); ?></td>
											</tr>
											<tr>
												<th scope="row">Blood Group</th>
												<td><?php echo e($client->blood_group); ?></td>
											</tr>
											<tr>
												<th scope="row">Address</th>
												<td><?php echo e($client->billing_address . ', ' . $client->billing_area); ?></td>
											</tr>
											<tr>
												<th scope="row">City/District</th>
												<td><?php echo e($client->billing_city); ?></td>
											</tr>
											<tr>
												<th scope="row">State/Division</th>
												<td><?php echo e($client->billing_state); ?></td>
											</tr>
											<tr>
												<th scope="row">Postcode</th>
												<td><?php echo e($client->billing_postcode); ?></td>
											</tr>
										</tbody>
									</table>
							</div>
						</div>

						<div class="col-xl-7">
							<div class="customers-wrapper">
								<h4 class="w-100 text-center mb-3">Order History</h4>
								<table class="table table-striped">
									<thead class="thead-light">
										<tr>
											<th scope="col">#</th>
											<th scope="col">Order NO</th>
											<th scope="col">Total</th>
											<th scope="col">Status</th>
										</tr>
									</thead>
									<tbody>
									<?php $__empty_1 = true; $__currentLoopData = $client->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
										<tr>
											<th scope="row"><?php echo e($index + 1); ?></th>
											<td>
												<a href="<?php echo e(route('admin.orders.single', ['no' => $order->order_no])); ?>"><?php echo e($order->order_no); ?></a>
											</td>
											<td> <i class="sbicon sbicon-bdt"> </i> <?php echo e(number_format($order->order_total, 2)); ?></td>
											<td><?php echo e($order->order_progress); ?></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<?php endif; ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>