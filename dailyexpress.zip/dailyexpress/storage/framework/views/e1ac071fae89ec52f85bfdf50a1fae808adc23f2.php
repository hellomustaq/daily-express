<h4 id="toggleFilterProduct" class="d-lg-none" v-tooltip.top-center="'Open Filter Menu'">
	Filter Products <i class="icon ion-ios-arrow-down"></i>
</h4>

<aside class="shop-sidebar" id="shopSidebar">
	<div class="shop-sidebar-image-top d-none d-lg-block">
		<?php if(Route::currentRouteName() == 'category.single' && isset($category) && $category->isParent()): ?>
			<?php if($catBanner = getBanners('category_sidebar_banner_' . $category->category_id, true)): ?>
				<a class="d-block p-0" href="<?php echo e($catBanner->banner_target_url); ?>" <?php if($catBanner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
					<img src="<?php echo e(imageCache($catBanner->banner_img)); ?>" class="w-100 h-100" alt="">
				</a>
			<?php else: ?>
				<a class="d-block p-0" href="#">
					<img src="https://via.placeholder.com/300x490?text=(300x490+px)" class="w-100 h-100" alt="">
				</a>
			<?php endif; ?>
		<?php else: ?>
			<?php if($catBanner = getBanners('sidebar_banner', true)): ?>
				<a class="d-block p-0" href="<?php echo e($catBanner->banner_target_url); ?>" <?php if($catBanner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
					<img src="<?php echo e(imageCache($catBanner->banner_img)); ?>" class="w-100 h-100" alt="">
				</a>
			<?php else: ?>
				<a class="d-block p-0" href="#">
					<img src="https://via.placeholder.com/300x490?text=(300x490+px)" class="w-100 h-100" alt="">
				</a>
			<?php endif; ?>
		<?php endif; ?>
	</div>

	<div class="sidebar-filter">
		<h2>Filter by Price</h2>
		<div id="priceRange"></div>
		<form id="filterForm" action="<?php echo e(request()->fullUrl()); ?>" method="get">
			<input type="hidden" name="minP" value="<?php echo e(request()->get('minP') ? request()->get('minP') : $minPrice); ?>">
			<input type="hidden" name="maxP" value="<?php echo e(request()->get('maxP') ? request()->get('maxP') : $maxPrice); ?>">
			<input type="hidden" name="size" value="<?php echo e(request()->get('size')); ?>">
			<input type="hidden" name="color" value="<?php echo e(request()->get('color')); ?>">
			<input type="hidden" name="brand" value="<?php echo e(request()->get('brand')); ?>">
			<input type="hidden" name="sortBy" value="<?php echo e(request()->get('sortBy')); ?>">
			<input type="hidden" name="page" value="<?php echo e(request()->get('page')); ?>">
			<button type="submit" class="btn btn-success float-right" style="margin-top: 15px;">Filter</button>
		</form>
	</div>

	<div class="sidebar-lists" style="margin-top: 70px;">
		<h2>Manufacturer</h2>
		<ul>
			<?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<li>
				<a href="javascript:void(0)" @click.prevent="submitFilterParam('brand', '<?php echo e($brand->pb_name); ?>')"><?php echo e($brand->pb_name); ?></a>
			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

			<?php endif; ?>
		</ul>
	</div>

	<div class="sidebar-lists">
		<h2>Filter by Color</h2>
		<ul>
			<?php $__empty_1 = true; $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<li>
					<a href="javascript:void(0)" @click.prevent="submitFilterParam('color', '<?php echo e($color); ?>')"><?php echo e($color); ?></a>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<li>No Color Found</li>
			<?php endif; ?>
		</ul>
	</div>

	<div class="sidebar-lists">
		<h2>Filter by Size</h2>
		<ul>
			<?php $__empty_1 = true; $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<li>
					<a href="javascript:void(0)" @click.prevent="submitFilterParam('size', '<?php echo e($size); ?>')"><?php echo e($size); ?></a>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<li>No Size Found</li>
			<?php endif; ?>
		</ul>
	</div>

	<div class="shop-sidebar-image-top d-none d-lg-block">
		<?php if($catBanner = getBanners('sidebar_banner', true)): ?>
			<a class="d-block p-0" href="<?php echo e($catBanner->banner_target_url); ?>" <?php if($catBanner->banner_target_url_type == 'external'): ?> target="_blank" <?php endif; ?>>
				<img src="<?php echo e(imageCache($catBanner->banner_img)); ?>" class="w-100 h-100" alt="">
			</a>
		<?php else: ?>
			<a class="d-block p-0" href="#">
				<img src="https://via.placeholder.com/300x490?text=(300x490+px)" class="w-100 h-100" alt="">
			</a>
		<?php endif; ?>
	</div>
</aside>
<?php /**PATH /home/dailyexp/Franchise/theme/views/partials/shop-sidebar.blade.php ENDPATH**/ ?>