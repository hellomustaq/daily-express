<?php $__env->startSection('sub-title', 'Add Customers'); ?>
<?php $__env->startSection('page-description', 'Add Customers'); ?>

<?php $__env->startSection('customers-active', 'active'); ?>
<?php $__env->startSection('customers-new-active', 'active'); ?>

<?php $__env->startSection('header-action'); ?>

	<ul class="nav justify-content-end">
		<li class="nav-item text-center">
			<a href="<?php echo e(route('admin.customers')); ?>" class="nav-link btn btn-light">
				<i class="fa fa-users"> </i>
				<span class="d-sm-block">All Customers</span>
			</a>
		</li>
	</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
	<div class="customers-view">
		<div class="card new-client">
			<div class="card-header">
				<strong><i class="fa fa-plus"> </i> Add</strong> New Customer
			</div>
			<div class="card-body">
				<form action="<?php echo e(route('admin.customers.add')); ?>" method="POST">
					<?php echo csrf_field(); ?>
					<div class="form-group row">
						<label for="first_name" class="col-sm-2 col-form-label">Name</label>
						<label for="last_name" class="sr-only">Last Name</label>
						<div class="col-sm-5">
							<input type="text" class="form-control <?php echo e($errors->has('first_name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('first_name')); ?>"
								   id="first_name" name="first_name" placeholder="First Name" required autofocus>
							<?php if($errors->has('first_name')): ?>
								<span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                </span>
							<?php endif; ?>
						</div>
						<div class="col-sm-5">
							<input type="text" class="form-control <?php echo e($errors->has('last_name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('last_name')); ?>"
								   id="last_name" name="last_name" placeholder="Last Name" required>
							<?php if($errors->has('last_name')): ?>
								<span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('last_name')); ?></strong>
                                </span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="email" class="col-sm-2 col-form-label">Email</label>
						<div class="col-sm-10">
							<input type="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>"
								   id="email" name="email" placeholder="Email Address">
							<?php if($errors->has('email')): ?>
								<span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="mobile" class="col-sm-2 col-form-label">Mobile No</label>
						<div class="col-sm-10">
							<input type="tel" class="form-control <?php echo e($errors->has('mobile') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('mobile')); ?>"
								   id="mobile" name="mobile" placeholder="Mobile Number" required>
							<?php if($errors->has('mobile')): ?>
								<span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('mobile')); ?></strong>
                                </span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="password" class="col-sm-2 col-form-label">Password</label>
						<div class="col-sm-10">
							<input type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" id="password"
								   name="password" placeholder="Password" aria-describedby="passwordHelp" required>
							<small id="passwordHelp" class="form-text text-muted">
								Password must be at least 8 characters.
							</small>
							<?php if($errors->has('password')): ?>
								<span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group row">
						<label for="confPassword" class="col-sm-2 col-form-label">Confirm Password</label>
						<div class="col-sm-10">
							<input type="password" class="form-control" id="confPassword" name="password_confirmation" placeholder="Confirm Password" required>
						</div>
					</div>

					<div class="form-group row">
						<div class="col-sm-10 offset-sm-2">
							<input type="submit" class="btn btn-success" value="Create Client">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/customers/add.blade.php ENDPATH**/ ?>