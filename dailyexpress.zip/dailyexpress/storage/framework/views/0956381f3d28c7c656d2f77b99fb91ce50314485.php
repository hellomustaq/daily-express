<?php $__env->startSection('sub-title', 'Edit Home Sliders'); ?>
<?php $__env->startSection('page-description', 'Edit Home Sliders'); ?>

<?php $__env->startSection('ads-active', 'active'); ?>
<?php $__env->startSection('ads-sliders-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-ads">
        <promotional-banner
                page-title="Home Sliders"
                img-placeholder="https://via.placeholder.com/1335x750?text=Promotional+Image(1335x750)"
                api="<?php echo e(route('admin.api.ads.sliders')); ?>">
        </promotional-banner>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/ads/sliders.blade.php ENDPATH**/ ?>