<?php $__env->startSection('sub-title', 'Edit Category Banners'); ?>
<?php $__env->startSection('page-description', 'Edit Category Banners'); ?>

<?php $__env->startSection('ads-active', 'active'); ?>
<?php $__env->startSection('ads-category-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-ads">
        <category-banner
                page-title="Category Banner"
                :categories="<?php echo e(json_encode($categories)); ?>"
                api="<?php echo e(route('admin.api.ads.category_banners')); ?>">
        </category-banner>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/ads/category_banners.blade.php ENDPATH**/ ?>