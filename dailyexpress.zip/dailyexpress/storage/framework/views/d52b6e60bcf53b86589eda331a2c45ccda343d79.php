<?php $__env->startSection('content'); ?>
    <div class="login-box">
        <?php if(Session::has('sa_status') && Session::get('sa_status') == 'created'): ?>
            <div class="alert alert-success text-center" role="alert">
                Super Admin successfully created. <br>
                Please login to continue...
            </div>
        <?php endif; ?>
        
        <?php if(isset($timeout_status) && $timeout_status): ?>
            <div class="alert alert-warning text-center text-danger" style="font-size: 14px; font-weight: 600;" role="alert">
                Your session has been expired due to inactivity for 90 minutes. <br>
                Please login to again to continue...
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header text-center">
                Login to <strong>"<?php echo e($site_title); ?>"</strong> Admin Panel
            </div>

            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="email" class="sr-only">Email address</label>
                        <div class="input-group mb-3">
                            <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>"
                                   placeholder="Email" aria-label="Email" aria-describedby="basic-addon2" id="email" required autofocus>
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2"><i class="fa fa-envelope"></i></span>
                            </div>
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password" class="sr-only">Password</label>
                        <div class="input-group mb-3">
                            <input type="password" name="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                   placeholder="Password" aria-label="Password" aria-describedby="basic-addon3" id="password" required>
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon3"><i class="fa fa-key"></i></span>
                            </div>
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="customCheck1" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="custom-control-label" for="customCheck1">Remember Me</label>
                        </div>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Login')); ?>

                        </button>

                        <a class="btn btn-link" href="<?php echo e(route('admin.password.email')); ?>">
                            <?php echo e(__('Forgot Your Password?')); ?>

                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>