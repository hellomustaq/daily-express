

<?php $__env->startSection('title', 'Checkout :: '); ?>
<?php $__env->startSection('description', 'Submit & Checkout your order.'); ?>
<?php $__env->startSection('keywords', getSiteBasic('site_keywords')); ?>

<?php $__env->startSection('breadcrumb'); ?>
	<?php $__env->startComponent('theme::components.breadcrumb', [
			'data'  => [
				//['url' => '#', 'title' => 'Shop']
			],
			'active'   => 'Checkout'
		]); ?>
	<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="checkout-view">
		<checkout></checkout>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dailyexpress/theme/views/checkout.blade.php ENDPATH**/ ?>