<?php $__env->startSection('sub-title', 'Create Delivery Method'); ?>
<?php $__env->startSection('page-description', 'Create Delivery Method'); ?>

<?php $__env->startSection('shipping-active', 'active'); ?>
<?php $__env->startSection('shipping-new-active', 'active'); ?>


<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">

        <?php if(Session::has('status')): ?>
            <div class="alert alert-info text-center" role="alert">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card new-admin">
            <div class="card-header">
                <strong><i class="fa fa-truck"></i> Create</strong> Delivery Method
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.shipping.add')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="method_name" class="col-md-3 col-form-label">Method Name</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control <?php echo e($errors->has('method_name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('method_name')); ?>"
                                   id="method_name" name="method_name" placeholder="Method Name" required autofocus>
                            <?php if($errors->has('method_name')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('method_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="method_charge" class="col-md-3 col-form-label">Charge</label>
                        <div class="col-md-9">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">
                                        <i class="sbicon sbicon-bdt"> </i>
                                    </span>
                                </div>
                                <input type="text" class="form-control <?php echo e($errors->has('method_charge') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('method_charge')); ?>"
                                       id="method_charge" name="method_charge" placeholder="Charge"  >
                                <?php if($errors->has('method_charge')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('method_charge')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="method_time" class="col-md-3 col-form-label">Estimated Time</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control <?php echo e($errors->has('method_time') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('method_time')); ?>"
                                   id="method_time" name="method_time" placeholder="Estimated Time" required>
                            <?php if($errors->has('method_time')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('method_time')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="method_note" class="col-md-3 col-form-label">Note</label>
                        <div class="col-md-9">
                            <textarea class="form-control <?php echo e($errors->has('method_note') ? 'is-invalid' : ''); ?>" name="method_note" id="method_note" rows="4" style="resize: none;"><?php echo old('method_note'); ?></textarea>

                            <?php if($errors->has('method_note')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('method_note')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="method_available_outside" class="col-md-3 col-form-label">Outside Dhaka</label>
                        <div class="col-md-9">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="customRadioInline1" name="method_available_outside" value="1" class="custom-control-input">
                                <label class="custom-control-label" for="customRadioInline1">Yes</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="customRadioInline2" name="method_available_outside" value="0" class="custom-control-input" checked>
                                <label class="custom-control-label" for="customRadioInline2">No</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="method_active" class="col-md-3 col-form-label">Status</label>
                        <div class="col-md-9">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="customRadioInline3" name="method_active" value="1" class="custom-control-input" checked>
                                <label class="custom-control-label" for="customRadioInline3">Active</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="customRadioInline4" name="method_active" value="0" class="custom-control-input">
                                <label class="custom-control-label" for="customRadioInline4">Inactive</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-9 offset-md-3">
                            <button class="btn btn-success" type="submit">Create Method</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom-script'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/shipping-method/create.blade.php ENDPATH**/ ?>