<?php $__env->startSection('sub-title', 'Franchise Products'); ?>
<?php $__env->startSection('page-description', 'View All Franchise Products'); ?>

<?php $__env->startSection('products-active', 'active'); ?>
<?php $__env->startSection('products-own-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-products">
        <product-data-table
                api_url="<?php echo e(route('admin.api.products.franchise')); ?>"
                :franchise-own="true"
                product_type="all">
        </product-data-table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/products/franchise.blade.php ENDPATH**/ ?>