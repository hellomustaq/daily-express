<?php $__env->startSection('sub-title', 'Franchise Checkout'); ?>
<?php $__env->startSection('page-description', 'Franchise Checkout'); ?>

<?php $__env->startSection('dashboard-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="franchise-checkout checkout-view">
        <checkout>

        </checkout>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/checkout.blade.php ENDPATH**/ ?>