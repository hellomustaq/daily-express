

<?php $__env->startSection('sub-title', 'Pages - All'); ?>
<?php $__env->startSection('page-description', 'All Pages'); ?>

<?php $__env->startSection('pages-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">

        <?php if(Session::has('status')): ?>
            <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <strong><i class="fa fa-file-text-o"></i> All</strong> Pages
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th scope="col">Title</th>
                            <th scope="col" class="text-center">Author</th>
                            <th scope="col" class="text-center">Status</th>
                            <th scope="col" class="text-center">Date</th>
                            <th scope="col" class="text-center">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row">
                                    <a href="<?php echo e(url($page->post_slug)); ?>">
                                        <?php echo e($page->post_title); ?>

                                    </a>
                                </th>
                                <td class="text-center"><?php echo e($page->author->name); ?></td>
                                <td class="text-center"><?php echo e($page->post_active ? 'Published' : 'Draft'); ?></td>
                                <td class="text-center"><?php echo e($page->created_at->toDateString()); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url($page->post_slug)); ?>" target="_blank" class="btn btn-info text-white" title="View"><i class="fa fa-eye"></i></a>
                                    <a href="<?php echo e(route('admin.pages.edit', ['id' => $page->post_id])); ?>" class="btn btn-warning text-white" title="Edit"><i class="fa fa-pencil"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/Franchise/resources/views/admin/pages/index.blade.php ENDPATH**/ ?>