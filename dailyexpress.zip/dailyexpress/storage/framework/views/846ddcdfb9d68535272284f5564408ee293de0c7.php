<?php $__env->startSection('sub-title', 'Dashboard'); ?>
<?php $__env->startSection('page-description', 'RBT Ecom Dashboard'); ?>

<?php $__env->startSection('dashboard-active', 'active'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="dashboard-header" style="background-image: url('<?php echo e(asset("assets/RBT_EMS/images/dashboard_header.jpg")); ?>');">
        <div class="dashboard-header-content">
            <div class="row">
                <div class="col-sm-7">
                    <h1 class="header-welcome">
                        Welcome <strong><?php echo e(auth('admin')->user()->first_name); ?></strong>
                        <br>
                        <small>Have a Great Day!</small>
                    </h1>
                </div>
                <div class="col-sm-5 text-center">
                    <div class="wow jackInTheBox animated" data-wow-delay="150ms">
                        <h3 class="dashboard-header-information">
                            <?php echo e($location->temperature); ?>&deg; C
                            <br>
                            <small><i class="fa fa-map-marker"></i> <?php echo e($location->city . ', ' . $location->country); ?></small>
                        </h3>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/home.blade.php ENDPATH**/ ?>