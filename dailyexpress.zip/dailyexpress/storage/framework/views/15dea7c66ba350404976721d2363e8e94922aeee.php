

<?php $__env->startSection('sub-title', 'Shop Shipping Methods'); ?>
<?php $__env->startSection('page-description', 'All Shop Shipping Methods'); ?>

<?php $__env->startSection('shipping-active', 'active'); ?>
<?php $__env->startSection('shipping-all-active', 'active'); ?>

<?php $__env->startSection('header-action'); ?>
    <ul class="nav justify-content-end">
        <li class="nav-item text-center">
            <a class="nav-link btn btn-light" href="<?php echo e(route('admin.shipping.add')); ?>">
                <i class="fa fa-plus"> </i>
                <span class="d-none d-sm-block">Create Method</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">

        <?php if(Session::has('status')): ?>
            <div class="alert alert-info text-center" role="alert">
                <?php echo e(Session::get('status')); ?>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <strong><i class="fa fa-truck"> </i> All</strong> Shipping Methods
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Charge</th>
                            <th scope="col">Estimated Time</th>
                            <th scope="col">Outside Dhaka</th>
                            <th scope="col">Status</th>
                            <th scope="col">Note</th>
                            <th scope="col" style="width: 110px;">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($method->method_name); ?></th>
                                <td><?php echo e($method->method_charge); ?></td>
                                <td><?php echo e($method->method_time); ?></td>
                                <td><?php echo e(($method->method_available_outside) ? 'Yes' : 'No'); ?></td>
                                <td><?php echo e(($method->method_active) ? 'Active' : 'Inactive'); ?></td>
                                <td><?php echo e($method->method_note); ?></td>
                                <td class="text-center" style="width: 110px;">
                                    <!-- Button trigger modal -->
                                    <a href="<?php echo e(route('admin.shipping.edit', ['id' => $method->method_id])); ?>" class="btn btn-warning" title="Edit">
                                        <i class="fa fa-pencil"> </i>
                                    </a>
                                    <button type="button" class="btn btn-danger text-white"  title="Delete" data-toggle="modal" data-target="#deleteModal<?php echo e($method->method_id); ?>">
                                        <i class="fa fa-trash"> </i>
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="deleteModal<?php echo e($method->method_id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteModalLabel">Delete Method</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    Are you sure want to remove "<?php echo e($method->method_name); ?>" as a <strong>Delivery Method</strong>?
                                                </div>
                                                <div class="modal-footer">
                                                    <form action="<?php echo e(route('admin.shipping.delete')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($method->method_id); ?>">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">Confirm</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/shipping-method/index.blade.php ENDPATH**/ ?>