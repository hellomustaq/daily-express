<?php $__env->startSection('sub-title', 'All Categories'); ?>
<?php $__env->startSection('page-description', 'View All Categories'); ?>

<?php $__env->startSection('categories-active', 'active'); ?>
<?php $__env->startSection('categories-all-active', 'active'); ?>

<?php $__env->startSection('header-action'); ?>
    <ul class="nav justify-content-end">
        <li class="nav-item text-center">
            <a class="nav-link btn btn-light" href="<?php echo e(route('admin.categories.create')); ?>">
                <i class="fa fa-plus"></i>
                <span class="d-none d-sm-block">New Category</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="admin-categories">
        <div class="admin-content-header-summary">
            <div class="row">
                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header rbt-bg-main">Main <strong>Categories</strong></h5>
                        <div class="card-body rbt-text-main">
                            <span><?php echo e($summary->main); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header">Sub <strong>Categories</strong></h5>
                        <div class="card-body">
                            <span><?php echo e($summary->sub); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header">Filtering <strong>Categories</strong></h5>
                        <div class="card-body">
                            <span><?php echo e($summary->filtering); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header">Inactive <strong>Categories</strong></h5>
                        <div class="card-body">
                            <span><?php echo e($summary->inactive); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="all-categories">
            <div class="card">
                <div class="card-header">
                    <strong>All</strong> Categories
                </div>
                <div class="card-body">
                    <div class="accordion" id="accordionCategories">
                        <ul class="list-group">
                            <?php for($i = 0; $i < count($parents); $i++): ?>
                                <div class="card">
                                    <div class="card-header" id="heading<?php echo e($i); ?>">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link <?php echo e(($i > 0) ? 'collapsed' : ''); ?>" style="color: #394263;" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($i); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($i); ?>">
                                                <strong><?php echo e($parents[$i]->category_title); ?></strong>
                                            </button>
                                            <span>
                                                <a href="<?php echo e(route('admin.categories.edit', ['id' => $parents[$i]->category_id])); ?>">
                                                    <i class="fa fa-pencil" style="margin-left: 5px;"></i>
                                                </a>
                                            </span>
                                        </h5>
                                    </div>

                                    <div id="collapse<?php echo e($i); ?>" class="collapse <?php echo e(($i == 0) ? 'show' : ''); ?>" aria-labelledby="heading<?php echo e($i); ?>" data-parent="#accordionCategories">
                                        <div class="card-body">
                                            <ul class="list-group">
                                                <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($child->category_parent_id == $parents[$i]->category_id): ?>
                                                        <li class="list-group-item">
                                                            <?php echo e($child->category_title); ?>

                                                            <span>
                                                                <a href="<?php echo e(route('admin.categories.edit', ['id' => $child->category_id])); ?>">
                                                                    <i class="fa fa-pencil" style="margin-left: 5px;"></i>
                                                                </a>
                                                            </span>
                                                            <ul>
                                                                <?php $__currentLoopData = $filterings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filtering): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($filtering->category_parent_id == $child->category_id): ?>
                                                                        <li>
                                                                            <?php echo e($filtering->category_title); ?>

                                                                            <span>
                                                                                <a href="<?php echo e(route('admin.categories.edit', ['id' => $filtering->category_id])); ?>">
                                                                                    <i class="fa fa-pencil" style="margin-left: 5px;"></i>
                                                                                </a>
                                                                            </span>
                                                                        </li>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        </li>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endfor; ?>
                        </ul>

                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>