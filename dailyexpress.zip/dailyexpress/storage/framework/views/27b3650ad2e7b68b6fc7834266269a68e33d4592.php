<?php $__env->startSection('sub-title', 'All Customers'); ?>
<?php $__env->startSection('page-description', 'All Customers'); ?>

<?php $__env->startSection('customers-active', 'active'); ?>
<?php $__env->startSection('customers-all-active', 'active'); ?>

<?php $__env->startSection('header-action'); ?>

	<ul class="nav justify-content-end">
		<li class="nav-item text-center">
			<a href="<?php echo e(route('admin.customers.add')); ?>" class="nav-link btn btn-light">
				<i class="fa fa-plus"> </i>
				<span class="d-sm-block">Create</span>
			</a>
		</li>
	</ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
	<div class="customers-view rbt-data-table">
		<?php if(Session::has('status')): ?>
			<div class="alert alert-info text-center" role="alert">
				<?php echo e(Session::get('status')); ?>

			</div>
		<?php endif; ?>

		<div class="card">
			<div class="card-header">
				<strong><i class="fa fa-users"> </i> All</strong> Clients
			</div>
			<div class="card-body">
				<?php if($clients and $clients > 0): ?>
					<clients-data-table
							api-url="<?php echo e(route('admin.api.clients.all')); ?>">
					</clients-data-table>
				<?php else: ?>
					<div class="alert alert-danger py-5" role="alert">
						No Customers Found!
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>