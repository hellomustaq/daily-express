<?php $__env->startSection('content'); ?>
    <div class="forgot-password-box">
        <div class="card">
            <div class="card-header"><?php echo e(__('Reset Password')); ?></div>

            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.password.email')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="email" class="sr-only">Email address</label>
                        <div class="input-group mb-3">
                            <input type="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('email')); ?>"
                                   placeholder="Email" aria-label="Email" aria-describedby="basic-addon2" id="email" required autofocus>
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2"><i class="fa fa-envelope"></i></span>
                            </div>
                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <?php echo e(__('Send Password Reset Link')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/auth/passwords/email.blade.php ENDPATH**/ ?>