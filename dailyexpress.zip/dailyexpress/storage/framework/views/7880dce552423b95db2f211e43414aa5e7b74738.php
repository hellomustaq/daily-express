

<?php $__env->startSection('sub-title', 'View Order'); ?>
<?php $__env->startSection('page-description', 'View the order details'); ?>

<?php $__env->startSection('orders-active', 'active'); ?>
<?php $__env->startSection('orders-create-active', 'active'); ?>


<?php $__env->startSection('admin-content'); ?>
    <div class="admin-orders-create">

        <div class="admin-content-header-summary">
            <div class="row">
                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header rbt-bg-main"><strong>Orders</strong> Pending</h5>
                        <div class="card-body rbt-text-main">
                            <span><?php echo e(getOrderSummary()->pending); ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Orders</strong> Today</h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->today; ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Orders</strong> This Month</h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->this_month; ?></span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-xl-3">
                    <div class="card text-center">
                        <h5 class="card-header"><strong>Orders</strong> Last Month</h5>
                        <div class="card-body">
                            <span><?php echo getOrderSummary()->last_month; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <create-order></create-order>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/domains/dailyexpressbd.com/Franchise/resources/views/admin/orders/create.blade.php ENDPATH**/ ?>