<?php $__env->startSection('title', 'Login :: '); ?>
<?php $__env->startSection('description', getSiteBasic('site_description')); ?>
<?php $__env->startSection('keywords', getSiteBasic('site_keywords')); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__env->startComponent('theme::components.breadcrumb', [
            'data'  => [
                //['url' => '#', 'title' => 'Shop']
            ],
            'active'   => 'Login'
        ]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="login-view auth-view">
        <div class="container my-3 my-md-5">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10">
                    <?php if(session(('error'))): ?>
                        <div class="alert alert-danger" role="alert">
                            <span class="h5 font-weight-bold"><?php echo e(session('error')); ?></span>
                        </div>
                    <?php endif; ?>
                </div>


                <div class="col-md-6 col-lg-5" style="background-color: #1b1b1b;">
                    <div class="login-side">
                        <h3 class="d-none d-md-block">Shop With Confidence</h3>
                        <img src="<?php echo e(asset("images/shop_circle.png")); ?>" alt="" class="mw-100 d-none d-md-block hvr-grow-rotate">

                        <h4>
                            Get Started
                        </h4>

                        <span class="d-block">with</span>

                        <a href="<?php echo e(route('login.social', ['driver' => 'facebook'])); ?>" v-tooltip.top-bottom="'Login With Facebook'"
                           class="btn btn-light hvr-grow-rotate" style="background-color: #365dad;">
                            <i class="icon ion-logo-facebook"></i>
                        </a>
                        <a href="<?php echo e(route('login.social', ['driver' => 'google'])); ?>" v-tooltip.top-bottom="'Login With Google+'"
                           class="btn btn-light hvr-grow-rotate" style="background-color: #dd4e40;">
                            <i class="icon ion-logo-googleplus"></i>
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-5" style="border: 2px solid #1b1b1b;">
                    <div class="card bsoft-card">
                        <div class="card-header text-center">
                            Login OR Register
                        </div>

                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('login')); ?>" id="login-form">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="email" class="sr-only">Email/Mobile</label>
                                    <div class="input-group <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon2">
                                                <i class="icon ion-ios-contact hvr-grow"></i>
                                            </span>
                                        </div>
                                        <input type="text" name="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('email')); ?>"
                                               placeholder="Email or Mobile Number" aria-label="Email" aria-describedby="basic-addon2" id="email" required autofocus>
                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="password" class="sr-only">Password</label>
                                    <div class="input-group <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon3">
                                                <i class="icon ion-md-lock hvr-grow"></i>
                                            </span>
                                        </div>
                                        <input type="password" name="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                               placeholder="Password" aria-label="Password" aria-describedby="basic-addon3" id="password" required>

                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group secured-btn text-center">
                                    <?php echo NoCaptcha::renderJs(); ?>

                                    <?php echo NoCaptcha::displaySubmit('login-form', 'Continue', ['data-theme' => 'dark']); ?>

                                    
                                </div>
                            </form>
                        </div>
                    </div>
                    <a class="btn btn-link forgot-btn" href="<?php echo e(route('password.request')); ?>" v-tooltip.top-bottom="'Click to Reset Your Password'">
                        <?php echo e(__('Forgot Password?')); ?>

                    </a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dailyexp/Franchise/theme/views/auth/login.blade.php ENDPATH**/ ?>