<?php $__env->startSection('sub-title', 'Social Page Linking'); ?>
<?php $__env->startSection('page-description', 'Social Page Linking'); ?>

<?php $__env->startSection('site-information-active', 'active'); ?>
<?php $__env->startSection('site-social-active', 'active'); ?>



<?php $__env->startSection('admin-content'); ?>
    <div class="all-admins-container">
        <div class="card new-admin">
            <div class="card-header">
                <strong><i class="fa fa-superpowers"></i> Social</strong> Links
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('shop_info.social')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group row">
                        <label for="facebook_page" class="col-sm-3 col-form-label">Facebook Page</label>
                        <div class="col-sm-9">
                            <input type="url" class="form-control <?php echo e($errors->has('facebook_page') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('facebook_page')); ?>"
                                   id="facebook_page" name="facebook_page" placeholder="Facebook Page URL" autofocus>
                            <?php if($errors->has('facebook_page')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('facebook_page')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="youtube_channel" class="col-sm-3 col-form-label">Youtube Channel </label>
                        <div class="col-sm-9">
                            <input type="url" class="form-control <?php echo e($errors->has('youtube_channel') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('youtube_channel')); ?>"
                                   id="youtube_channel" name="youtube_channel" placeholder="Youtube Channel URL">
                            <?php if($errors->has('youtube_channel')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('youtube_channel')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="instagram_page" class="col-sm-3 col-form-label">Instagram Page</label>
                        <div class="col-sm-9">
                            <input type="url" class="form-control <?php echo e($errors->has('instagram_page') ? 'is-invalid' : ''); ?>" value="<?php echo e(getSiteBasic('instagram_page')); ?>"
                                   id="instagram_page" name="instagram_page" placeholder="Instagram Page URL">
                            <?php if($errors->has('instagram_page')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('instagram_page')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-9 offset-sm-3">
                            <input type="submit" class="btn btn-success" value="Save">
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\resources\views/admin/site-information/social.blade.php ENDPATH**/ ?>