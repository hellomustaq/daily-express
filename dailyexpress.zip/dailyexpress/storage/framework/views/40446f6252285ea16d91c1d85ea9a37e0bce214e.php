<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="breadcrumb-item">
                <a href="<?php echo e($item['url']); ?>"><?php echo e($item['title']); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
        <li class="breadcrumb-item active" aria-current="page">
            <?php echo e($active); ?>

        </li>
    </ol>
</nav>
<?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\theme/views/components/breadcrumb.blade.php ENDPATH**/ ?>