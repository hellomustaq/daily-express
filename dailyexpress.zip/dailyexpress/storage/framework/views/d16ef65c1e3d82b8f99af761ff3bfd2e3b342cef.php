<div class="product-grid">
    <div class="product-image">
        <a href="<?php echo e(route('product.single', ['slug' => $product->product_slug])); ?>">
            <?php echo e($image); ?>

            
        </a>

        <?php if($product->product_featured == 1): ?>
            <div class="product-label featured-label">
                <span class="label-text">FEATURED</span>
            </div>
        <?php endif; ?>

        <?php if($product->product_discounted): ?>
            <div class="product-label discounted-label">
                <span class="label-text">
                    <?php if($product->product_discount_amount && $product->product_discount_amount > 0): ?>
                        - <i class="sbicon sbicon-bdt"></i><?php echo e($product->product_discount_amount); ?>

                    <?php else: ?>
                        - <?php echo e($product->product_discount_percentage); ?> %
                    <?php endif; ?>
                </span>
            </div>
        <?php endif; ?>
        <?php if($product->product_offered): ?>
            <div class="product-label offered-label">
                <span class="label-text">OFFERED</span>
            </div>
        <?php endif; ?>

        <div class="quick-button">
            <a href="javascript:void(0)" role="button" class="quick-view-btn" @click.prevent="openQuickViewModal(<?php echo e($product->product_id); ?>)" v-tooltip.top-center="'Click to Quick View'">
                <i class="icon ion-ios-eye"></i>
            </a>

            <a href="javascript:void(0)" class="add-to-wishlist-btn" @click.prevent="addToWishList(<?php echo e($product->product_id); ?>)" v-tooltip.top-center="'Add To Wishlist'" data-id="<?php echo e($product->product_id); ?>">
                <i class="icon ion-md-heart-empty"></i>
            </a>
        </div>
    </div>

    <div class="product-content">
        <div class="product-title">
            <h4>
                <a href="<?php echo e(route('product.single', ['slug' => $product->product_slug])); ?>">
                    <?php echo e($product->product_title); ?>

                </a>
            </h4>
        </div>

        <div class="product-rating">

        </div>

        <div class="product-unit">
            <?php echo e(floatval($product->product_unit_quantity) . ' ' . $product->product_unit_name); ?>

        </div>

        <div class="product-price">
            <?php if($product->product_discounted == 0): ?>
                <span class="current-price">
                    <i class="sbicon sbicon-bdt"></i><?php echo e(number_format($product->product_unit_mrp, 2)); ?>

                </span>
            <?php else: ?>
                <span class="current-price">
                    <i class="sbicon sbicon-bdt"></i><?php echo e(number_format($product->product_discounted_price, 2)); ?>

                </span>
                <span class="old-price">
                    <i class="sbicon sbicon-bdt"></i><?php echo e(number_format($product->product_unit_mrp, 2)); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="product-action">
            <a href="javascript:void(0)" role="button" style="display: none;" class="quick-view-btn" @click="openQuickViewModal(<?php echo e($product->product_id); ?>)" v-tooltip.top-center="'Click to Quick View'">
                <i class="icon ion-ios-eye"></i>
            </a>

            <?php if($product->product_available_sizes || $product->product_available_colors): ?>
                <a href="<?php echo e(route('product.single', ['slug' => $product->product_slug])); ?>" v-tooltip.top-center="'Click to Buy'">
                    <i class="icon ion-md-cart"></i> Buy Now
                </a>
            <?php else: ?>
                <a href="javascript:void(0)" v-tooltip.top-center="'Add to Cart'" @click="addToCart(<?php echo e($product->product_id); ?>)" data-id="<?php echo e($product->product_id); ?>">
                    <i class="icon ion-md-cart"></i> Add To Cart
                </a>
            <?php endif; ?>

            <a href="javascript:void(0)" style="display: none;" class="add-to-wishlist-btn" @click="addToWishList(<?php echo e($product->product_id); ?>)" v-tooltip.top-center="'Add To Wishlist'" data-id="<?php echo e($product->product_id); ?>">
                <i class="icon ion-md-heart-empty"></i>
            </a>
        </div>

        <div class="product-desc" style="display: none;">
            <p><?php echo e(Str::limit(strip_tags($product->product_description), 180)); ?></p>
        </div>

    </div>
</div>
<?php /**PATH D:\Office Work\ECOM APP\New Franchise\24 November\Franchise\theme/views/components/product-grid.blade.php ENDPATH**/ ?>